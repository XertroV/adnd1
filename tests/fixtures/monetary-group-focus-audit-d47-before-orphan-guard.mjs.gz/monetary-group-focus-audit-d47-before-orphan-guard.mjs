// Duplicate authored table-row recipes must agree. Agreement is not source proof.
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(key=>`${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`:JSON.stringify(value);
const sha=value=>createHash('sha256').update(typeof value==='string'?value:canonical(value)).digest('hex');
const escape=value=>String(value).replaceAll('~','~0').replaceAll('/','~1');
function differences(a,b,path='') {
 if(canonical(a)===canonical(b))return [];
 if(a&&b&&typeof a==='object'&&typeof b==='object'&&Array.isArray(a)===Array.isArray(b))return [...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(key=>differences(a[key],b[key],`${path}/${escape(key)}`));
 return [{path,before:a===undefined?null:a,after:b===undefined?null:b,beforePresent:a!==undefined,afterPresent:b!==undefined}];
}
const sourceIdentity=source=>({book:source?.bookKey??source?.book??null,sha256:source?.sourceFileSha256??source?.sourcePdfSha256??null,printedPage:source?.printedPage??null,pdfPage:source?.pdfPage??null});
function declarations(value,path='',out=[]) {
 if(Array.isArray(value))value.forEach((child,index)=>declarations(child,`${path}/${index}`,out));
 else if(value&&typeof value==='object')for(const[key,child]of Object.entries(value)){
  const pointer=`${path}/${escape(key)}`;
  if(['focusBoundsCropPixelsLTRB','focusRectsCropPixelsLTRB'].includes(key))out.push({pointer,kind:key,value:structuredClone(child),sha256:sha(child),scope:pointer.startsWith('/review/groups/')?'grouped-row':pointer.startsWith('/review/sourceRowsOrClaims/')?(pointer.includes('/sourceContextParts/')?'ordered-part':'primary-row'):pointer.startsWith('/additionalReferenceSheetReview/')?'reference-comparator':'other-declaration-needs-classification'});
  declarations(child,pointer,out);
 }
 return out;
}
function groupFoci(value,path='',out=[]) {
 if(Array.isArray(value))value.forEach((child,index)=>groupFoci(child,`${path}/${index}`,out));
 else if(value&&typeof value==='object')for(const[key,child]of Object.entries(value)){
  if(key==='focus')out.push({pointer:`${path}/focus`,parent:value,focus:child});
  else groupFoci(child,`${path}/${escape(key)}`,out);
 }
 return out;
}
function primaryFor(group,parent,rows){
 const cohort=rows.filter(row=>row.groupId===group.recordId);
 if(group.recordId==='phb-assassination-fees'&&Number.isInteger(parent.assassinLevel))return cohort.filter(row=>row.sourceKind==='fee-matrix-row'&&row.objectOrSubject===`assassin level ${parent.assassinLevel} fee row`);
 if(group.recordId==='dmg-poison-dose-and-manufacture'&&typeof parent.route==='string'&&typeof parent.poisonClass==='string')return cohort.filter(row=>row.sourceKind==='poison-price-row'&&row.objectOrSubject===`${parent.route} poison class ${parent.poisonClass}`&&row.conditions?.route===parent.route);
 return [];
}
function target(focus,source,crops){
 if(!focus||typeof focus!=='object'||Array.isArray(focus))return null;
 const single=Object.hasOwn(focus,'focusBoundsCropPixelsLTRB'),multiple=Object.hasOwn(focus,'focusRectsCropPixelsLTRB');
 if(single===multiple)return null;
 const crop=crops.get(focus.contextCropId),rectangles=single?[focus.focusBoundsCropPixelsLTRB]:focus.focusRectsCropPixelsLTRB;
 const pair=value=>Array.isArray(value)&&value.length===2&&value.every(n=>Number.isInteger(n)&&n>0),bounds=crop?.cropBoundsPixelsLTRB;
 if(!crop||!pair(crop.sourceRenderDimensionsPx)||!pair(crop.cropDimensionsPx)||!/^[a-f0-9]{64}$/.test(crop.sourceRenderSha256||'')||!/^[a-f0-9]{64}$/.test(crop.cropSha256||'')||!Array.isArray(bounds)||bounds.length!==4||!bounds.every(Number.isInteger)||bounds[0]<0||bounds[1]<0||bounds[2]>crop.sourceRenderDimensionsPx[0]||bounds[3]>crop.sourceRenderDimensionsPx[1]||bounds[2]-bounds[0]!==crop.cropDimensionsPx[0]||bounds[3]-bounds[1]!==crop.cropDimensionsPx[1]||typeof focus.coordinateSpace!=='string'||!focus.coordinateSpace)return null;
 if(!Array.isArray(rectangles)||rectangles.length<(multiple?2:1)||rectangles.some(rect=>!Array.isArray(rect)||rect.length!==4||!rect.every(Number.isFinite)||rect[0]<0||rect[1]<0||rect[2]<=rect[0]||rect[3]<=rect[1]||rect[2]>crop.cropDimensionsPx[0]||rect[3]>crop.cropDimensionsPx[1]))return null;
 const s=sourceIdentity(source);if(!s.book||!/^[a-f0-9]{64}$/.test(s.sha256||'')||!Number.isInteger(s.pdfPage)||s.pdfPage<1||!Number.isInteger(s.printedPage)||s.printedPage<1)return null;
 return {source:s,cropId:focus.contextCropId,sourceRenderSha256:crop.sourceRenderSha256??null,sourceRenderDimensionsPx:crop.sourceRenderDimensionsPx??null,cropBoundsPixelsLTRB:crop.cropBoundsPixelsLTRB??null,cropDimensionsPx:crop.cropDimensionsPx??null,cropSha256:crop.cropSha256??null,coordinateSpace:focus.coordinateSpace??null,rectangles};
}
export function auditMonetaryGroupFocus(data){
 const rows=data?.review?.sourceRowsOrClaims,groups=data?.review?.groups,cropRows=data?.review?.evidenceCrops;
 if(!Array.isArray(rows)||!Array.isArray(groups)||!Array.isArray(cropRows))throw Error('Monetary group focus audit requires source rows, groups and evidence crops.');
 if(new Set(rows.map(row=>row.sourceRowOrClaimId)).size!==rows.length||rows.some(row=>typeof row.sourceRowOrClaimId!=='string'||!row.sourceRowOrClaimId))throw Error('Duplicate or missing primary monetary row identity.');
 if(new Set(cropRows.map(row=>row.cropId)).size!==cropRows.length)throw Error('Duplicate monetary evidence crop identity.');
 const crops=new Map(cropRows.map(c=>[c.cropId,c])),inventory=declarations(data),duplicates=[];
 for(const[gi,group]of groups.entries())for(const declared of groupFoci(group,`/review/groups/${gi}`)){
  const matches=primaryFor(group,declared.parent,rows),row=matches.length===1?matches[0]:null,ri=row?rows.indexOf(row):null,a=target(declared.focus,group.source,crops),b=row?target(row.focus,row.source,crops):null,aligned=Boolean(row&&a&&b),geometryEqual=aligned&&canonical(a)===canonical(b),fieldDiffs=row?differences(declared.focus,row.focus):[];
  duplicates.push({groupId:group.recordId,groupFocusPointer:declared.pointer,mainRowId:row?.sourceRowOrClaimId??null,mainFocusPointer:row?`/review/sourceRowsOrClaims/${ri}/focus`:null,alignment:matches.length!==1?(matches.length?'multiple-primary-row-matches':'no-supported-exact-source-row-match'):!a||!b?'source-or-focus-frame-unassessable':'exact-printed-row-identity-match',category:!aligned?'cannot-align':geometryEqual&&fieldDiffs.length===0?'matching':'differing',sourceGeometryCategory:!aligned?'cannot-align':geometryEqual?'matching':'differing',fullFocusObjectEqual:aligned&&fieldDiffs.length===0,allAuthoredFocusFieldDifferences:fieldDiffs,sourceTargetDifferences:aligned?differences(a,b):[],groupFocus:structuredClone(declared.focus),mainFocus:row?structuredClone(row.focus):null,groupTarget:a,mainTarget:b,sourcePixelCorrectness:'unassessed-by-duplicate-consistency-audit'});
 }
 const countBy=(items,key)=>items.reduce((out,item)=>(out[item[key]]=(out[item[key]]||0)+1,out),{}),unclassified=inventory.filter(row=>row.scope==='other-declaration-needs-classification');
 return {schemaVersion:1,artifactType:'monetary-group-focus-consistency-audit',scope:'Every authored focus rectangle declaration in this input, with every grouped focus aligned to an exact printed-row identity or left explicitly unassessable. Status and other focus fields are compared separately from physical source-target geometry. No source correctness, field value or grade is inferred.',counts:{primaryRows:rows.length,groups:groups.length,declaredFocusGeometryFields:inventory.length,declarationsByScope:countBy(inventory,'scope'),groupedFocusDuplicates:duplicates.length,byCategory:countBy(duplicates,'category'),bySourceGeometryCategory:countBy(duplicates,'sourceGeometryCategory'),metadataOnlyDifferences:duplicates.filter(d=>d.category==='differing'&&d.sourceGeometryCategory==='matching').length,unclassifiedDeclarations:unclassified.length},inventory,duplicates,validation:{consistent:duplicates.every(row=>row.category==='matching')&&unclassified.length===0,semanticCompleteness:false},limitations:['Matching duplicated recipes can both point at the wrong source row; mandatory source-reviewed primary-row findings remain separate.','Grouped-to-primary alignment uses exact semantic labels and qualifiers, never a first substring or array position. Unknown row schemas stay cannot-align.','Ordered multi-part support may legitimately use distinct passages; those declarations are inventoried but are not mistaken for duplicate grouped rows.']};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2),value=flag=>{const i=args.indexOf(flag);return i<0?null:args[i+1];},input=value('--input')||'research/source-audit-batch5-phb-dmg-additional-prices.json',bytes=readFileSync(input),report={...auditMonetaryGroupFocus(JSON.parse(bytes)),input:{path:input,sha256:createHash('sha256').update(bytes).digest('hex')}};const output=value('--output');if(output)writeFileSync(output,JSON.stringify(report,null,2)+'\n');else console.log(JSON.stringify(report,null,2));if(args.includes('--check')&&!report.validation.consistent)process.exitCode=1;
}
