// Numeric containment for explicitly source-reviewed context goldens only.
// Passing this contract never certifies source semantics, crop ink, or values.
const rect=value=>Array.isArray(value)&&value.length===4&&value.every(Number.isInteger)&&value[0]>=0&&value[1]>=0&&value[2]>value[0]&&value[3]>value[1];
const dimensions=value=>Array.isArray(value)&&value.length===2&&value.every(v=>Number.isInteger(v)&&v>0);
const sha=value=>/^[a-f0-9]{64}$/.test(value||'');
const contains=(outer,inner)=>outer[0]<=inner[0]&&outer[1]<=inner[1]&&outer[2]>=inner[2]&&outer[3]>=inner[3];
export function checkRequiredContextExtent(contextEvidence,contract){
 const base={semanticPass:false,scope:'Calibrated numeric source-frame containment only; independent source pixels and meaning remain required.'};
 const expected=contract?.sourceFrame,required=contract?.requiredRects;
 if(!expected||typeof expected.book!=='string'||!expected.book.trim()||!sha(expected.sourcePdfSha256)||!sha(expected.sourceRenderSha256)||!Number.isInteger(expected.pdfPage)||expected.pdfPage<1||!dimensions(expected.sourceRenderDimensionsPx)||!Array.isArray(required)||required.length===0||required.some(r=>!r||typeof r.id!=='string'||!r.id||!rect(r.bounds)||r.bounds[2]>expected.sourceRenderDimensionsPx[0]||r.bounds[3]>expected.sourceRenderDimensionsPx[1])||new Set(required.map(r=>r.id)).size!==required.length)return {...base,complete:false,status:'invalid-required-context-contract',rectResults:[]};
 if(contextEvidence?.status!=='declared-context-crop-metadata-linked')return {...base,complete:false,status:'context-metadata-unavailable-or-unresolved',rectResults:[]};
 const frame=contextEvidence.sourceFrame;
 if(!frame||frame.book!==expected.book||frame.pdfPage!==expected.pdfPage||frame.sourcePdfSha256!==expected.sourcePdfSha256||(Number.isInteger(expected.printedPage)&&frame.printedPage!==expected.printedPage))return {...base,complete:false,status:'source-frame-mismatch',rectResults:[]};
 const crops=[];
 if(!Array.isArray(contextEvidence.crops))return {...base,complete:false,status:'invalid-context-crop-list',rectResults:[]};
 for(const c of contextEvidence.crops||[]){
  if(!c||typeof c!=='object')return {...base,complete:false,status:'invalid-context-crop-list',rectResults:[]};
  const m=c.metadata;if(!m||m.sourceRenderSha256!==expected.sourceRenderSha256)continue;
  if(!dimensions(m.sourceRenderDimensionsPx)||m.sourceRenderDimensionsPx.some((v,i)=>v!==expected.sourceRenderDimensionsPx[i])||!rect(m.cropBoundsPixelsLTRB)||!dimensions(m.cropDimensionsPx)||m.cropDimensionsPx[0]!==m.cropBoundsPixelsLTRB[2]-m.cropBoundsPixelsLTRB[0]||m.cropDimensionsPx[1]!==m.cropBoundsPixelsLTRB[3]-m.cropBoundsPixelsLTRB[1]||m.cropBoundsPixelsLTRB[2]>m.sourceRenderDimensionsPx[0]||m.cropBoundsPixelsLTRB[3]>m.sourceRenderDimensionsPx[1]||!sha(m.cropSha256))return {...base,complete:false,status:'invalid-matching-source-crop-frame',rectResults:[]};
  crops.push(c);
 }
 const rectResults=required.map(r=>({id:r.id,requiredBounds:r.bounds,coveredByCropIds:crops.filter(c=>contains(c.metadata.cropBoundsPixelsLTRB,r.bounds)).map(c=>c.cropId)})),complete=rectResults.every(r=>r.coveredByCropIds.length>0);
 return {...base,complete,status:complete?'required-context-extent-contained':'required-context-extent-missing',rectResults};
}
