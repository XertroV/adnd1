import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {auditMonetaryRowIdentity,loadMonetaryRowIdentityAudit,collectMonetaryRowIdentityRecords,monetaryRowIdentityInputs,monetaryContextEvidenceFingerprint,monetaryContextPhysicalCropFingerprint,hash,uaContextFingerprintVersion} from '../tools/monetary-row-identity-audit.mjs';
import {loadMonetarySourceRenderFrames} from '../tools/monetary-source-render-frames.mjs';

const fixture=JSON.parse(readFileSync(new URL('./fixtures/monetary-row-identity-before.json',import.meta.url))),baseline=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-baseline.json',import.meta.url)));
const recordsFor=findings=>structuredClone(fixture.records.filter(r=>findings.some(f=>f.records.some(ref=>ref.uid===r.uid))));
const reviewBytes=Buffer.from('Synthetic independent-review protocol fixture; no real source approval.');
const reviewEvidence=new Map([['fixture-only',reviewBytes]]),evidence={path:'fixture-only',sha256:hash(reviewBytes)};
function sourceValueHashes(raw){const out={},relevant=/(?:typedValue|quantityOrScale|conditions?|qualifier|amount|currency|unit|rate|value|price|purpose|scale|formula)/i;function walk(value,path=''){if(Array.isArray(value)){value.forEach((v,i)=>walk(v,`${path}/${i}`));return;}if(value&&typeof value==='object'){for(const [key,child]of Object.entries(value))walk(child,`${path}/${key.replace(/~/g,'~0').replace(/\//g,'~1')}`);return;}if(path&&relevant.test(path.split('/')[1]||''))out[path]=hash(value);}walk(raw);return out;}

test('actual three distinct UA armor rows sharing wrong foci are detected before any repair',()=>{
 const findings=fixture.knownFindings.filter(f=>f.kind==='duplicate-wrong-row-focus');
 assert.equal(findings.length,3);assert.equal(fixture.sourceInputs.find(i=>i.key==='ua').sha256,'8ec8fcb1c937f1e5fdc86af87029a8defd1a4e9ee27c44ef9d0d84eef7e4577a');
 const report=auditMonetaryRowIdentity(recordsFor(findings),{knownFindings:findings});
 assert.equal(report.validation.valid,false);assert.equal(report.duplicateCandidates.length,3);
 assert.ok(report.duplicateCandidates.every(c=>c.status==='confirmed-wrong-row-focus'));
 for(const c of report.duplicateCandidates){assert.ok(c.evidence.some(e=>e.space==='pdf-page-points'));assert.ok(c.evidence.some(e=>e.space==='rendered-page-pixels'));}
});

test('unique in-bounds poison offsets remain source-confirmed failures outside duplicate detection',()=>{
 const findings=fixture.knownFindings.filter(f=>f.kind==='wrong-row-focus-independent-source-review');assert.equal(findings.length,9);
 const report=auditMonetaryRowIdentity(recordsFor(findings),{knownFindings:findings});
 assert.equal(report.duplicateCandidates.length,0);assert.equal(report.validation.valid,false);assert.equal(report.knownFindings.filter(f=>f.status==='confirmed-wrong-row-focus').length,9);
 const unreviewed=auditMonetaryRowIdentity(recordsFor(findings));assert.equal(unreviewed.validation.semanticRowIdentityComplete,false);assert.ok(unreviewed.records.every(r=>r.physicalRowIdentityReview==='unassessed-by-programmatic-inventory'));
});

test('known missing source markers are preserved separately and empty arrays are not automatic source failures',()=>{
 const findings=fixture.knownFindings.filter(f=>f.kind==='missing-source-marker');assert.equal(findings.length,3);
 const report=auditMonetaryRowIdentity(recordsFor(findings),{knownFindings:findings});assert.equal(report.counts.knownFindingStatus['confirmed-source-marker-omission'],3);
 const noSourceCensus=auditMonetaryRowIdentity(recordsFor(findings));assert.equal(noSourceCensus.knownFindings.length,0);assert.equal(noSourceCensus.validation.semanticRowIdentityComplete,false);
});

test('changing or deleting a known bad recipe cannot silently waive the source finding',()=>{
 const finding=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus'),records=recordsFor([finding]);
 records[1].geometry.filter(g=>g.role==='row-focus').forEach(g=>{g.bounds[1]+=30;g.bounds[3]+=30;});
 const changed=auditMonetaryRowIdentity(records,{knownFindings:[finding]});assert.equal(changed.validation.valid,false);assert.equal(changed.knownFindings[0].status,'focus-changed-needs-source-review');
 const missing=auditMonetaryRowIdentity(records.slice(0,1),{knownFindings:[finding]});assert.equal(missing.validation.valid,false);assert.equal(missing.knownFindings[0].status,'record-identity-changed-needs-source-review');
});

test('distinct aliases and shared prose require exact independent dispositions, even with a declared row link',()=>{
 const finding=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus'),records=recordsFor([finding]);
 for(const r of records)r.identity.sourceRowIds=['declared-shared-row'];
 const before=auditMonetaryRowIdentity(records);assert.equal(before.duplicateCandidates[0].status,'candidate-requires-source-review');assert.equal(before.duplicateCandidates[0].declaredSharedSourceRowLink,true);
 const review={id:'synthetic-shared-passage-disposition',independent:true,disposition:'legitimate-shared-passage',evidence,records:before.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};
 assert.equal(auditMonetaryRowIdentity(records,{reviews:[{...review,independent:false}],reviewEvidence}).duplicateCandidates[0].status,'candidate-requires-source-review');
 assert.equal(auditMonetaryRowIdentity(records,{reviews:[review]}).duplicateCandidates[0].status,'candidate-requires-source-review');
 assert.equal(auditMonetaryRowIdentity(records,{reviews:[review],reviewEvidence}).duplicateCandidates[0].status,'legitimate-shared-passage');
 review.records[0].focusGeometrySha256='b'.repeat(64);assert.equal(auditMonetaryRowIdentity(records,{reviews:[review],reviewEvidence}).duplicateCandidates[0].status,'candidate-requires-source-review');
});

test('a marker repair disposition binds the annotation itself and cannot approve a later omission',()=>{
 const finding=fixture.knownFindings.find(f=>f.kind==='missing-source-marker'),records=recordsFor([finding]);records[0].annotations['/footnoteMarkers']=[finding.expectedMarker];
 const snapshot=auditMonetaryRowIdentity(records),r=snapshot.records[0],review={id:'synthetic-source-marker-repair',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:[{uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,annotationSha256:r.annotationSha256}]};
 assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence}).validation.valid,true);
 records[0].annotations['/footnoteMarkers']=[];assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence}).validation.valid,false);
});

test('the complete frozen monetary body retains all row and nonrow denominators, NA and unknown states',()=>{
 assert.equal(baseline.capturedBeforeSourceFixes,true);assert.equal(baseline.counts.records,2161);
 assert.deepEqual(baseline.counts.recordsBySurface,{'canonical-source-row':710,'site-price-claim':191,'ua-supplement-row':583,'phb-dmg-supplement-row':179,'phb-reference-row-comparison':165,'reference-financial-context':9,'typed-passage':34,'passage-row-comparison':43,'typed-description':2,'description-variant-row':9,'description-pointer-link':8,'source-census-claim':180,'census-adjacent-review-issue':48});
 assert.equal(baseline.coverage.printedSitePrices,187);assert.equal(baseline.coverage.canonicalSitePriceGaps,4);assert.equal(baseline.counts.unhandledGeometry,0);
 assert.equal(baseline.records.filter(r=>r.notApplicable).length,12);assert.ok(baseline.records.some(r=>r.geometryStatus==='no-recorded-focus-geometry'));assert.equal(baseline.counts.knownFindings,15);
 assert.equal(baseline.inputManifest.find(i=>i.key==='passages').stage,'draft-independent-review-pending');assert.ok(baseline.duplicateCandidates.some(c=>c.status==='candidate-requires-source-review'));
});

test('all explicit adapters and production baseline inputs are required; there is no silent empty fallback',()=>{
 assert.throws(()=>collectMonetaryRowIdentityRecords(new Map()),/Missing monetary row-identity input/);
 const repoRoot=mkdtempSync(join(tmpdir(),'monetary-row-identity-'));
 try{assert.throws(()=>loadMonetaryRowIdentityAudit({repoRoot}),/price-source-inventory/);}finally{rmSync(repoRoot,{recursive:true,force:true});}
 const historical=loadMonetaryRowIdentityAudit({findingsPath:null,baselinePath:null,reviewsPath:null});assert.equal(historical.records.length,2161);assert.equal(historical.contextEvidenceCoverage.records,927);assert.match(historical.contextMigrationBridgeStatus,/not-provided/);
});

test('overlap candidates remain optional and distinct from exact duplicate row conflicts',()=>{
 const finding=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus'),records=recordsFor([finding]);records[1].geometry.filter(g=>g.role==='row-focus').forEach(g=>{g.bounds[1]+=1;g.bounds[3]+=1;});
 const without=auditMonetaryRowIdentity(records);assert.equal(without.optionalOverlapCandidates.length,0);
 const withOverlap=auditMonetaryRowIdentity(records,{includeOverlaps:true});assert.equal(withOverlap.duplicateCandidates.length,0);assert.ok(withOverlap.optionalOverlapCandidates.length>0);assert.equal(withOverlap.validation.semanticRowIdentityComplete,false);
});

test('the source-confirmed16-row armor extension stays bound to the immutable before corpus',()=>{
 const manifest=JSON.parse(readFileSync(new URL('../research/monetary-row-identity-findings.json',import.meta.url))),path='research/source-audit-batch5-monetary-row-identity-armor-extension.json',ref=manifest.extensions.find(r=>r.path===path);assert.ok(ref);
 const bytes=readFileSync(new URL('../'+path,import.meta.url)),extension=JSON.parse(bytes);assert.equal(hash(bytes),ref.sha256);assert.equal(extension.knownFindings.length,16);assert.equal(extension.baseline.sha256,hash(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-baseline.json',import.meta.url))));
 const audit=auditMonetaryRowIdentity(structuredClone(extension.records),{knownFindings:extension.knownFindings});assert.equal(audit.validation.valid,false);assert.equal(audit.knownFindings.filter(r=>r.status==='confirmed-wrong-row-focus').length,16);
});

function minimalDocuments(focus){
 const bodies={canonical:{sourceInventories:[],siteClaims:[],sourcePageCensuses:[]},ua:{rowRecords:[]},phbDmg:{review:{evidenceCrops:[{cropId:'crop',cropSha256:'b'.repeat(64),cropBoundsPixelsLTRB:[10,20,100,200],cropDimensionsPx:[90,180],sourceRenderSha256:'c'.repeat(64),sourceRenderDimensionsPx:[123,456]}],sourceRowsOrClaims:[{sourceRowOrClaimId:'row-01',objectOrSubject:'Synthetic row',source:{book:'PHB',printedPage:1,pdfPage:2,sourceSha256:'a'.repeat(64)},sourceKind:'synthetic-row',groupId:'test',focus}] }},passages:{records:[]},descriptions:{newSourceDescriptionRecords:[],pointerResolutionLinks:[]},receipts:{claimReceipts:[]},phbDmgCensus:{records:[]},uaCensus:{records:[]},monsterCensus:{claims:[]}};
 return new Map(monetaryRowIdentityInputs.map(c=>[c.key,{...c,sha256:'d'.repeat(64),data:bodies[c.key]}]));
}
function frozenSourceFixtureDocuments(){
 const docs=minimalDocuments({}),uaBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url))),pdBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url)));
 docs.set('ua',{...docs.get('ua'),sha256:hash(uaBytes),data:JSON.parse(uaBytes.toString('utf8'))});docs.set('phbDmg',{...docs.get('phbDmg'),sha256:hash(pdBytes),data:JSON.parse(pdBytes.toString('utf8'))});return docs;
}
function currentReviewRef(record){return {uid:record.uid,rowIdentitySha256:record.rowIdentitySha256,focusGeometrySha256:record.focusGeometrySha256,contextGeometrySha256:record.contextGeometrySha256,contextEvidenceSha256:record.contextEvidenceSha256,contextPhysicalFingerprintVersion:record.contextPhysicalFingerprintVersion,contextPhysicalEvidenceSha256:record.contextPhysicalEvidenceSha256,annotationSha256:record.annotationSha256,recordSha256:record.recordSha256};}

test('ordered disjoint focus rectangles are all inventoried and ambiguous old plus new shapes fail',()=>{
 const f={contextCropId:'crop',coordinateSpace:'crop-local 150-dpi source-render pixels',focusRectsCropPixelsLTRB:[[1,2,10,12],[20,30,40,50]]};
 const {records}=collectMonetaryRowIdentityRecords(minimalDocuments(f));assert.equal(records.length,1);assert.equal(records[0].geometry.length,4);assert.deepEqual(records[0].geometry.filter(g=>g.space==='crop-local-pixels').map(g=>g.bounds),f.focusRectsCropPixelsLTRB);assert.deepEqual(records[0].geometry.filter(g=>g.space==='rendered-page-pixels').map(g=>g.bounds),[[11,22,20,32],[30,50,50,70]]);
 assert.throws(()=>collectMonetaryRowIdentityRecords(minimalDocuments({...f,focusBoundsCropPixelsLTRB:[1,2,10,12]})),/Ambiguous single and multiple/);
 assert.throws(()=>collectMonetaryRowIdentityRecords(minimalDocuments({...f,focusRectsCropPixelsLTRB:[]})),/Invalid multiple/);
 assert.throws(()=>collectMonetaryRowIdentityRecords(minimalDocuments({...f,focusRectsCropPixelsLTRB:[[1,2,10,12]]})),/Invalid multiple/);
 assert.throws(()=>collectMonetaryRowIdentityRecords(minimalDocuments({...f,focusRectsCropPixelsLTRB:[[1,2,10,12],[5,6,20,30]]})),/Overlapping monetary/);
 assert.throws(()=>collectMonetaryRowIdentityRecords(minimalDocuments({...f,focusRectsCropPixelsLTRB:[[1,2,10,12],[20,30,100,50]]})),/outside crop/);
});

function uaPrimaryFocusDocuments({focus=[110,110,190,190],cropPoints=[100,100,200,200],role='primary-table-context'}={}){
 const docs=minimalDocuments({}),ua=docs.get('ua').data,sourceSha256='a'.repeat(64),renderSha256='b'.repeat(64),row={recordId:'ua-other-001-row-001',object:'Synthetic row',classification:'synthetic',sourceRowIdentity:{rowLabel:'Synthetic row',table:'Synthetic table',printedPage:10,pdfPage:11,rowIndexWithinGroup:1,segmentId:'synthetic-segment'},evidence:{sourcePdfSha256:sourceSha256,pageImageSha256:renderSha256,tableSegmentId:'synthetic-segment',rowHighlightBounds:{status:'recorded',pdfPagePoints:focus,renderedPagePixels:[150,150,250,250]},tableCropBounds:{pdfPagePoints:[0,0,300,300],renderedPagePixels:[0,0,417,417]},activeContextTargetLinks:[{targetId:'primary-crop',targetOrder:1,role,segmentId:'synthetic-segment'}]}};
 ua.source={book:'UA',sha256:sourceSha256};ua.rowRecords=[row];ua.groupReviews=[{groupId:'ua-other-001',sourcePdfSha256:sourceSha256,sourceEvidenceIndex:[{segmentId:'synthetic-segment',printedPage:10,pdfPage:11,sourcePdfSha256:sourceSha256,pageDimensionsPx:[417,417],tableCropBounds:{pdfPagePoints:[0,0,300,300],renderedPagePixels:[0,0,417,417]}}],activeContextTargets:[{targetId:'primary-crop',targetOrder:1,role,segmentId:'synthetic-segment',source:{book:'UA',sourcePdfSha256:sourceSha256,printedPage:10,pdfPage:11},sourceRender:{sourceRenderId:'synthetic-native-render',sourceRenderSha256:renderSha256,sourceRenderDimensionsPx:[417,417],renderDpi:100,coordinateSpace:'source-render pixels; top-left; LTRB half-open',pageBoundsPdfPagePointsTopLeftLTRB:[0,0,300,300]},crop:{cropBoundsPdfPagePointsTopLeftLTRB:cropPoints,cropBoundsPixelsLTRB:[139,139,278,278],cropDimensionsPx:[139,139],cropSha256:'c'.repeat(64),renderDpi:100,coordinateSpace:'source-render pixels; top-left; LTRB half-open'},pixelReview:{status:'synthetic-geometry-only'}}]}];
 return docs;
}

test('UA row highlight must fit its single linked primary table or passage crop (geometry only)',()=>{
 const read=docs=>{const records=collectMonetaryRowIdentityRecords(docs).records;return auditMonetaryRowIdentity(records);};
 const contained=read(uaPrimaryFocusDocuments());assert.equal(contained.records[0].uaPrimaryContextContainment.status,'row-focus-contained-in-primary-context-window');assert.equal(contained.validation.structuralErrors.length,0);assert.match(contained.records[0].uaPrimaryContextContainment.scope,/geometric-only/);
 const overhang=read(uaPrimaryFocusDocuments({cropPoints:[120,120,200,200]}));assert.equal(overhang.records[0].uaPrimaryContextContainment.status,'row-focus-exceeds-primary-context-window');assert.ok(overhang.validation.structuralErrors.some(error=>error.includes('row-focus-exceeds-primary-context-window')));
 const wrongRole=read(uaPrimaryFocusDocuments({role:'row-specific-table-context'}));assert.equal(wrongRole.records[0].uaPrimaryContextContainment.status,'linked-primary-focus-target-missing');assert.ok(wrongRole.validation.structuralErrors.some(error=>error.includes('linked-primary-focus-target-missing')));
 const prosePrimary=read(uaPrimaryFocusDocuments({role:'primary-source-passage-context'}));assert.equal(prosePrimary.records[0].uaPrimaryContextContainment.status,'row-focus-contained-in-primary-context-window');
});

test('crop-specific context findings can resolve supplemental ordered-part crops',()=>{
 const evidence={fingerprintVersion:'ordered-source-context-parts-v1',sourceFrame:{book:'DMG',printedPage:137,pdfPage:138,sourcePdfSha256:'a'.repeat(64)},sourceContextParts:[{cropId:'wand-left',source:{book:'DMG',printedPage:137,pdfPage:138,sourcePdfSha256:'a'.repeat(64)},sourceRender:{sourceRenderSha256:'b'.repeat(64),sourceRenderDimensionsPx:[1000,1400]},crop:{cropBoundsPixelsLTRB:[0,0,300,500],sourceRenderDimensionsPx:[1000,1400]}}],supplementalContextCrops:[{cropId:'wand-main-full-page',source:{book:'DMG',printedPage:137,pdfPage:138,sourcePdfSha256:'a'.repeat(64)},sourceRender:{sourceRenderSha256:'b'.repeat(64),sourceRenderDimensionsPx:[1000,1400]},metadata:{cropBoundsPixelsLTRB:[0,0,1000,1400],sourceRenderDimensionsPx:[1000,1400]}}]};
 const before=monetaryContextPhysicalCropFingerprint(evidence,'wand-main-full-page');assert.match(before,/^[a-f0-9]{64}$/);assert.equal(monetaryContextPhysicalCropFingerprint(evidence,'unknown-crop'),null);
 evidence.supplementalContextCrops[0].metadata.cropBoundsPixelsLTRB=[0,100,1000,1400];assert.notEqual(monetaryContextPhysicalCropFingerprint(evidence,'wand-main-full-page'),before);
});

test('an exact valid review for unrelated records cannot supersede a known finding',()=>{
 const finding=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus'),unrelated=fixture.knownFindings.find(f=>f.kind==='wrong-row-focus-independent-source-review'),records=recordsFor([finding,unrelated]);auditMonetaryRowIdentity(records);
 const r=records.find(r=>r.uid===unrelated.records[0].uid),review={id:'unrelated-repair',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:[{uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256}]};
 const report=auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence});assert.equal(report.reviewResults[0].status,'current-explicit-review');assert.equal(report.validation.valid,false);assert.equal(report.knownFindings[0].status,'confirmed-wrong-row-focus');
});

test('duplicate review IDs cannot borrow an earlier review acceptance',()=>{
 const finding=fixture.knownFindings[0],records=recordsFor([finding]);auditMonetaryRowIdentity(records);const refs=records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}));
 const good={id:'reused',independent:true,disposition:'legitimate-shared-passage',evidence,records:refs},bad={...good,independent:false,disposition:'source-reviewed-repair',supersedes:finding.id};
 assert.throws(()=>auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[good,bad],reviewEvidence}),/Duplicate or missing monetary review ID/);
});

test('cached row identity and geometry hashes cannot approve a mutated normalized record',()=>{
 const finding=fixture.knownFindings[0],records=recordsFor([finding]);records[1].geometry.filter(g=>g.role==='row-focus').forEach(g=>{g.bounds[1]+=30;g.bounds[3]+=30;});auditMonetaryRowIdentity(records);
 const review={id:'covered-repair',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};
 assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence}).validation.valid,true);
 records[0].label='Changed physical row';records[0].identity.label=records[0].label;
 const changed=auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence});assert.equal(changed.validation.valid,false);assert.equal(changed.reviewResults[0].status,'stale-or-incomplete-review');
 records[0].geometry[0].bounds=[1,2,1,2];assert.ok(auditMonetaryRowIdentity(records).validation.structuralErrors.length>0);
});

test('receipt joins require an exact bijection, not just matching denominators',()=>{
 const docs=minimalDocuments({contextCropId:'crop',focusBoundsCropPixelsLTRB:[1,2,10,12]});
 docs.get('canonical').data.sourcePageCensuses=[{claims:[{},{}]}];docs.get('phbDmgCensus').data.records=[{id:'a',source:{}},{id:'b',source:{}}];
 docs.get('receipts').data.claimReceipts=[{receiptId:'one',sourceCensusArtifact:docs.get('phbDmgCensus').path,sourceJsonPointer:'/records/0'},{receiptId:'two',sourceCensusArtifact:docs.get('phbDmgCensus').path,sourceJsonPointer:'/records/0'}];
 assert.throws(()=>collectMonetaryRowIdentityRecords(docs),/Duplicate monetary census receipt target/);
 docs.get('receipts').data.claimReceipts[1].sourceJsonPointer='/records/99';assert.throws(()=>collectMonetaryRowIdentityRecords(docs),/Missing exact monetary census receipt/);
});

test('runtime finding manifests cannot omit mandatory extensions or attach them to another baseline',()=>{
 const repoRoot=mkdtempSync(join(tmpdir(),'monetary-findings-'));
 try{
  for(const [,doc]of minimalDocuments({contextCropId:'crop',focusBoundsCropPixelsLTRB:[1,2,10,12]})){mkdirSync(join(repoRoot,'research'),{recursive:true});writeFileSync(join(repoRoot,doc.path),JSON.stringify(doc.data));}
  const before={schemaVersion:1,reviewDispositions:{knownFindings:[fixture.knownFindings[0]]}},beforeBytes=JSON.stringify(before),basePath='research/before.json',extPath='research/extension.json';writeFileSync(join(repoRoot,basePath),beforeBytes);
  const extension={schemaVersion:1,baseline:{path:basePath,sha256:hash(beforeBytes)},knownFindings:[fixture.knownFindings[3]]};
  const saveExtension=()=>{const bytes=JSON.stringify(extension);writeFileSync(join(repoRoot,extPath),bytes);writeFileSync(join(repoRoot,'research/monetary-row-identity-findings.json'),JSON.stringify({schemaVersion:1,baseline:{path:basePath,sha256:hash(beforeBytes)},extensions:[{path:extPath,sha256:hash(bytes)}]}));};saveExtension();
  const reviewPath=join(repoRoot,'empty-review-override.json');writeFileSync(reviewPath,JSON.stringify({reviews:[]}));
  const loaded=loadMonetaryRowIdentityAudit({repoRoot,reviewsPath:reviewPath});assert.equal(loaded.knownFindings.length,2);assert.equal(loaded.findingExtensions.length,1);
  const partial=join(repoRoot,'partial-baseline.json');writeFileSync(partial,JSON.stringify({reviewDispositions:{knownFindings:[]}}));assert.throws(()=>loadMonetaryRowIdentityAudit({repoRoot,reviewsPath:reviewPath,baselinePath:partial}),/Immutable monetary baseline hash mismatch/);
  extension.baseline.sha256='0'.repeat(64);saveExtension();assert.throws(()=>loadMonetaryRowIdentityAudit({repoRoot,reviewsPath:reviewPath}),/Monetary extension baseline identity mismatch/);
 }finally{rmSync(repoRoot,{recursive:true,force:true});}
});

test('current geometry hashes describe the actual post-role-rewrite metadata',()=>{
 const records=structuredClone(baseline.records.filter(r=>r.geometry.some(g=>g.role==='editorial-comparator-context'))),report=auditMonetaryRowIdentity(records);
 const comparators=report.records.flatMap(r=>r.geometry.filter(g=>g.role==='editorial-comparator-context'));assert.equal(comparators.length,18);
 for(const g of comparators)assert.equal(g.geometrySha256,hash({space:g.space,bounds:g.bounds,source:g.source,frame:g.frame,role:g.role}));
 assert.ok(comparators.every(g=>g.supersededComputedGeometrySha256));
});

test('recorded geometry collisions distinguish actual highlights from source locators',()=>{
 const report=auditMonetaryRowIdentity(structuredClone(baseline.records));
 assert.equal(report.counts.duplicateCandidates,1536);
 assert.deepEqual(report.counts.duplicateGeometryEvidenceKind,{'only-row-locator-pair':1386,'contains-actual-focus-pair':118,'only-passage-locator-pair':32});
 assert.equal(report.counts.identityCompleteness.label.recorded+report.counts.identityCompleteness.label.missing,2161);
 assert.equal(report.validation.semanticRowIdentityComplete,false);
});

test('direct collector hashes comparator metadata after assigning its context role',()=>{
 const documents=minimalDocuments({});documents.get('canonical').data.siteClaims=[{itemId:'synthetic-estimate',name:'Synthetic estimate',printedPrice:null,estimate:{comparatorEvidenceBindings:[{book:'PHB',pdfPage:2,sourceSha256:'a'.repeat(64),cropCoordinates:[{regionId:'synthetic',format:'x0-y0-x1-y1',coordinateSpace:'catalog-bounds-pdf-points-as-recorded',rect:[10,20,100,200]}],regionEvidence:[{regionId:'synthetic',imageSha256:'b'.repeat(64)}],highlightCoordinates:[{regionId:'synthetic',rects:[[0.1,0.2,0.3,0.4]]}]}]}}];
 const {records}=collectMonetaryRowIdentityRecords(documents),geometry=records.find(r=>r.surface==='site-price-claim').geometry;assert.equal(geometry.length,3);
 for(const g of geometry){assert.equal(g.role,'editorial-comparator-context');assert.equal(g.geometrySha256,hash({space:g.space,bounds:g.bounds,source:g.source,frame:g.frame,role:g.role}));}
});

test('complete source QA extension retains all dimensions and exact ten-marker census without duplicate row counts',()=>{
 const manifest=JSON.parse(readFileSync(new URL('../research/monetary-row-identity-findings.json',import.meta.url))),path='research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',ref=manifest.extensions.find(r=>r.path===path),bytes=readFileSync(new URL('../'+path,import.meta.url)),e=JSON.parse(bytes);assert.equal(hash(bytes),ref.sha256);assert.equal(e.knownFindings.length,77);assert.equal(e.counts.totalKnownFindingRecords,108);assert.equal(e.counts.totalKnownReferencedDistinctRows,193);
 assert.equal(e.sourceGeometryCensuses.phbDmg.namedGeometryFindingGroups,21);assert.equal(e.sourceGeometryCensuses.phbDmg.namedGroupAffectedUniqueRows,123);assert.equal(e.sourceGeometryCensuses.phbDmg.sharedOrOverbroadRowsOutsideNamedGroups.length,18);assert.equal(e.markerAssociationCensus.rows,10);
 const poison=e.markerAssociationCensus.records.find(r=>r.recordId==='ua-other-002-potion-a1-cont-r029');assert.deepEqual(poison.sourceExpected,['**']);assert.deepEqual(poison.supersededWrongSourceExpected,['*','**']);
 const report=auditMonetaryRowIdentity(structuredClone(e.records),{knownFindings:e.knownFindings});assert.equal(report.validation.structuralErrors.length,0);assert.equal(report.validation.unresolvedKnownFindingIds.length,77);
});

test('the sealed 145 unchanged-review false passes stay pending on frozen UA and PHB/DMG source inputs',()=>{
 const frozen=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-unchanged-repair-protocol-before.json',import.meta.url))),manifest=JSON.parse(readFileSync(new URL('../research/monetary-row-identity-findings.json',import.meta.url)));
 const expected=frozen.cases.filter(f=>f.acceptedAsRepair);assert.equal(frozen.denominator.registeredFindings,164);assert.equal(expected.length,145);
 const docs=new Map();for(const config of monetaryRowIdentityInputs){let bytes=readFileSync(new URL('../'+config.path,import.meta.url));if(config.key==='ua')bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url)));if(config.key==='phbDmg')bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url)));docs.set(config.key,{...config,sha256:hash(bytes),data:JSON.parse(bytes.toString('utf8'))});}
 assert.equal(docs.get('ua').sha256,'8ec8fcb1c937f1e5fdc86af87029a8defd1a4e9ee27c44ef9d0d84eef7e4577a');assert.equal(docs.get('phbDmg').sha256,'b0d46959c44e0d156ef5d40326af48c1f1ce9ee5b282a870c06c41010b94dcc9');
 const known=[...baseline.reviewDispositions.knownFindings];for(const ext of manifest.extensions){const bytes=readFileSync(new URL('../'+ext.path,import.meta.url));assert.equal(hash(bytes),ext.sha256);known.push(...JSON.parse(bytes.toString('utf8')).knownFindings);}
 const current=auditMonetaryRowIdentity(collectMonetaryRowIdentityRecords(docs).records).records,byUid=new Map(current.map(r=>[r.uid,r])),reviews=expected.map((finding,i)=>({id:`unchanged-source-review-${i}`,independent:true,disposition:'source-reviewed-repair',supersedes:finding.findingId,evidence,records:(known.find(f=>f.id===finding.findingId)?.records||[]).map(ref=>{const r=byUid.get(ref.uid);assert.ok(r,ref.uid);const pointers=known.find(f=>f.id===finding.findingId)?.confirmedPointers||[];return {uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,contextGeometrySha256:r.contextGeometrySha256,...(r.contextEvidenceSha256?{contextEvidenceSha256:r.contextEvidenceSha256}:{}),recordSha256:r.recordSha256,annotationSha256:r.annotationSha256,confirmedPointerSha256:Object.fromEntries(pointers.map(p=>typeof p==='string'?p:p.pointer).filter(p=>r.sourceValueSha256ByPointer?.[p]).map(p=>[p,r.sourceValueSha256ByPointer[p]]))};})}));
 const report=auditMonetaryRowIdentity(current,{knownFindings:known,reviews,reviewEvidence});for(const old of expected){const result=report.knownFindings.find(f=>f.id===old.findingId);assert.ok(result,old.findingId);assert.notEqual(result.status,'explicit-source-reviewed-repair',old.findingId);assert.notEqual(result.status,'explicit-source-reviewed-qualified-representation',old.findingId);}
 assert.equal(report.knownFindings.filter(f=>expected.some(old=>old.findingId===f.id)&&f.status.startsWith('explicit-source-reviewed')).length,0);
});

test('focus repair requires a changed nonempty target while the untouched duplicate member may remain',()=>{
 const f=baseline.reviewDispositions.knownFindings.find(f=>f.id==='ua-armor-duplicate-wrong-row-1'),records=recordsFor([f]);
 const unchanged=auditMonetaryRowIdentity(records),noOp={id:'unchanged-duplicate-focus-review',independent:true,disposition:'source-reviewed-repair',supersedes:f.id,evidence,records:unchanged.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};
 assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[noOp],reviewEvidence}).knownFindings[0].status,'confirmed-wrong-row-focus');
 const samePair=recordsFor([f]);for(const r of samePair)for(const g of r.geometry.filter(g=>g.role==='row-focus'))g.bounds[1]+=12;const stillDuplicate=auditMonetaryRowIdentity(samePair),samePairReview={...noOp,records:stillDuplicate.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};assert.equal(stillDuplicate.duplicateCandidates.length,1);assert.notEqual(auditMonetaryRowIdentity(samePair,{knownFindings:[f],reviews:[samePairReview],reviewEvidence}).knownFindings[0].status,'explicit-source-reviewed-repair');
 records[0].geometry.find(g=>g.role==='row-focus').bounds[1]+=12;const changed=auditMonetaryRowIdentity(records),review={...noOp,records:changed.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};
 assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[review],reviewEvidence}).knownFindings[0].status,'explicit-source-reviewed-repair');
 records[0].geometry=records[0].geometry.filter(g=>g.role!=='row-focus');const deleted=auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[{...review,records:records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256}))}],reviewEvidence});assert.notEqual(deleted.knownFindings[0].status,'explicit-source-reviewed-repair');
});

test('typed-content repair binds changed authored pointers from the frozen b0d source row',()=>{
 const pdBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url))),pd=JSON.parse(pdBytes.toString('utf8')),row=pd.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId==='dmg-placement-not-gem-1000'),finding=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-not-gem-qualifier-extension.json',import.meta.url))).knownFindings[0],docs=new Map();
 for(const config of monetaryRowIdentityInputs){let bytes=readFileSync(new URL('../'+config.path,import.meta.url));if(config.key==='ua')bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url)));if(config.key==='phbDmg')bytes=pdBytes;docs.set(config.key,{...config,sha256:hash(bytes),data:JSON.parse(bytes.toString('utf8'))});}
 const original=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid===finding.records[0].uid),beforeReport=auditMonetaryRowIdentity([original]),before=beforeReport.records[0],pointers=finding.confirmedPointers,oldReview={id:'unchanged-typed-review',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:[{uid:before.uid,rowIdentitySha256:before.rowIdentitySha256,focusGeometrySha256:before.focusGeometrySha256,contextGeometrySha256:before.contextGeometrySha256,contextEvidenceSha256:before.contextEvidenceSha256,recordSha256:before.recordSha256,confirmedPointerSha256:Object.fromEntries(pointers.map(p=>[p.pointer,before.sourceValueSha256ByPointer[p.pointer]]))}]};
 assert.equal(auditMonetaryRowIdentity([original],{knownFindings:[finding],reviews:[oldReview],reviewEvidence}).knownFindings[0].status,'confirmed-typed-content-mismatch');
 row.typedValue.qualifier=pointers[0].sourceCorrection;row.quantityOrScale=pointers[1].sourceCorrection;const repairedRaw=JSON.parse(JSON.stringify(pd));repairedRaw.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId===row.sourceRowOrClaimId).typedValue.qualifier=row.typedValue.qualifier;repairedRaw.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId===row.sourceRowOrClaimId).quantityOrScale=row.quantityOrScale;const repairedBytes=Buffer.from(JSON.stringify(repairedRaw)),nextDocs=new Map(docs);nextDocs.set('phbDmg',{...docs.get('phbDmg'),sha256:hash(repairedBytes),data:repairedRaw});const next=collectMonetaryRowIdentityRecords(nextDocs).records.find(r=>r.uid===finding.records[0].uid),snapshot=auditMonetaryRowIdentity([next]),current=snapshot.records[0],review={...oldReview,id:'changed-authored-typed-fields-review',records:[{uid:current.uid,rowIdentitySha256:current.rowIdentitySha256,focusGeometrySha256:current.focusGeometrySha256,contextGeometrySha256:current.contextGeometrySha256,contextEvidenceSha256:current.contextEvidenceSha256,recordSha256:current.recordSha256,confirmedPointerSha256:Object.fromEntries(pointers.map(p=>[p.pointer,current.sourceValueSha256ByPointer[p.pointer]]))}]};
 assert.equal(auditMonetaryRowIdentity([next],{knownFindings:[finding],reviews:[review],reviewEvidence}).knownFindings[0].status,'explicit-source-reviewed-repair');
});

function uaDoubleStarReviewProbe({mutateRows=()=>{},mutateReview=()=>{},mutateFinding=()=>{}}={}){
 const extension=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-ua-double-star-tokenization-extension.json',import.meta.url))),qa=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',import.meta.url))),finding=structuredClone(extension.knownFindings[0]),focusFinding=qa.knownFindings.find(f=>f.id==='ua-remaining-focus-ua-other-002-potion-a2-r038');assert.ok(focusFinding);
 const docs=frozenSourceFixtureDocuments(),ua=docs.get('ua').data,adjudication=extension.independentPixelAdjudication;
 for(const entry of finding.records){const index=Number(entry.sourceRecordPointer.split('/')[2]),row=ua.rowRecords[index];row.footnoteMarkers=['**'];row.footnoteMarkerNormalizationV3={status:'exact token normalization proposal; pending source review',before:['*','*'],after:['**'],sourcePdfSha256:entry.sourceFrame.sourcePdfSha256,sourceDefinitionId:entry.sourceDefinitionId,sourceDefinitionAdjudicationPath:adjudication.path,sourceDefinitionAdjudicationSha256:adjudication.sha256,reason:'These two original rows visibly carry a double-star glyph; exact-array correction is separate from marker meaning/applicability.'};}
 const first=ua.rowRecords[54];first.evidence.rowHighlightBounds={status:'candidate-precise-row-bounds; independent overlay review pending',pdfPagePoints:[310.75,213.56,584.25,223.39],renderedPagePixels:[777.0855,533.9567,1461.0145,558.5345],derivation:'Candidate full-source focus update; this does not approve the separate focus finding.'};
 mutateRows(ua,finding);docs.get('ua').sha256=hash(Buffer.from(JSON.stringify(ua)));const current=auditMonetaryRowIdentity(collectMonetaryRowIdentityRecords(docs).records.filter(r=>finding.records.some(ref=>ref.uid===r.uid))).records;
 const review={id:'synthetic-exact-UA-double-star-review',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:current.map(record=>{const entry=finding.confirmedPointers.find(pointer=>pointer.uid===record.uid),index=Number(entry.pointer.split('/')[2]);return {...currentReviewRef(record),confirmedPointerSha256:{[entry.pointer]:hash(ua.rowRecords[index].footnoteMarkers)}};})};mutateReview(review,current);mutateFinding(finding);
 const report=auditMonetaryRowIdentity(current,{knownFindings:[finding,focusFinding],reviews:[review],reviewEvidence});return {report,finding,focusFinding,review,current,ua};
}

test('the immutable UA double-star finding accepts only the exact reviewed token array while leaving focus separate',()=>{
 const {report,finding,focusFinding,current}=uaDoubleStarReviewProbe(),token=report.knownFindings.find(f=>f.id===finding.id),focus=report.knownFindings.find(f=>f.id===focusFinding.id);
 assert.equal(report.reviewResults[0].status,'current-explicit-review');assert.equal(token.status,'explicit-source-reviewed-repair');assert.equal(focus.status,'focus-changed-needs-source-review');assert.equal(report.validation.valid,false);
 for(const ref of finding.records){const now=current.find(r=>r.uid===ref.uid);assert.equal(now.rowIdentitySha256,ref.rowIdentitySha256);assert.deepEqual(now.annotations['/footnoteMarkers'],['**']);}
 assert.notEqual(current.find(r=>r.uid===finding.records[0].uid).focusGeometrySha256,finding.records[0].focusGeometrySha256);
});

test('UA token review rejects pointer, token, semantic, source, and forged-contract changes',()=>{
 const negatives=[
  ['both old single markers',ua=>{ua.rowRecords[54].footnoteMarkers=['*','*'];ua.rowRecords[61].footnoteMarkers=['*','*'];}],
  ['only one fixed',ua=>{ua.rowRecords[61].footnoteMarkers=['*','*'];}],
  ['wrong token',ua=>{ua.rowRecords[54].footnoteMarkers=['***'];}],
  ['extra token',ua=>{ua.rowRecords[54].footnoteMarkers=['**','*'];}],
  ['source value changed',ua=>{ua.rowRecords[61].values.gpSaleValue.amount=9999;}],
  ['source PDF changed',ua=>{ua.rowRecords[54].evidence.sourcePdfSha256='f'.repeat(64);}],
 ] ;
 for(const [label,mutateRows]of negatives){const {report,finding}=uaDoubleStarReviewProbe({mutateRows});assert.notEqual(report.knownFindings.find(f=>f.id===finding.id).status,'explicit-source-reviewed-repair',label);assert.notEqual(report.reviewResults[0].status,'current-explicit-review',label);}
 const findingPointer=uid=>uid.endsWith('r038')?'/rowRecords/54/footnoteMarkers':'/rowRecords/61/footnoteMarkers',controls=[
  ['forged absolute-pointer hash',(_,review)=>{review.records[0].confirmedPointerSha256[findingPointer(review.records[0].uid)]='f'.repeat(64);}],
  ['missing current record hash',(_,review)=>{delete review.records[0].recordSha256;}],
  ['foreign UID',(_,review)=>{review.records[0].uid='ua-supplement-row:foreign-row';}],
  ['extra reviewed pointer',(_,review)=>{review.records[0].confirmedPointerSha256['/rowRecords/54/footnoteMarkers']='0'.repeat(64);}],
  ['forged normalization metadata',ua=>{ua.rowRecords[54].footnoteMarkerNormalizationV3.reason='generic duplicate collapse';}],
 ];
 for(const [label,mutate]of controls){const {report,finding}=uaDoubleStarReviewProbe({mutateRows:ua=>{if(mutate.length===1)mutate(ua);},mutateReview:(review,current)=>{if(mutate.length===2)mutate(current,review);}});assert.notEqual(report.knownFindings.find(f=>f.id===finding.id).status,'explicit-source-reviewed-repair',label);assert.notEqual(report.reviewResults[0].status,'current-explicit-review',label);}
 const {report,finding}=uaDoubleStarReviewProbe({mutateFinding:f=>{f.confirmedPointers[0].expectedValue=['***'];f.confirmedPointers[0].sourceCorrection=['***'];}});assert.notEqual(report.knownFindings.find(x=>x.id===finding.id).status,'explicit-source-reviewed-repair');
});

test('ordered source-context parts keep the Deck Gem page 142 choice and page 143 value frames separate',()=>{
 const docs=minimalDocuments({contextCropId:'crop-page-143',focusBoundsCropPixelsLTRB:[10,10,70,70],coordinateSpace:'crop-local 300-dpi source-render pixels'}),pd=docs.get('phbDmg'),row=pd.data.review.sourceRowsOrClaims[0],pdfSha='a'.repeat(64),crop=(cropId,renderSha,cropSha)=>({groupId:'test',cropId,label:cropId,sourceRender:`${cropId}.png`,sourceRenderSha256:renderSha,sourceRenderDimensionsPx:[800,1000],cropBoundsPixelsLTRB:[100,200,300,400],cropDimensionsPx:[200,200],cropSha256:cropSha,renderDpi:300});
 row.source={book:'DMG',printedPage:143,pdfPage:144,sourceSha256:pdfSha};row.contextCropId='crop-page-143';row.focus.contextCropId='crop-page-143';row.focus.focusBoundsCropPixelsLTRB=[10,10,70,70];row.typedValue={quantityChoice:'20 jewelry or 50 gems',gemBaseValueGpEach:1000};
 pd.data.review.evidenceCrops=[crop('crop-page-142','b'.repeat(64),'c'.repeat(64)),crop('crop-page-143','d'.repeat(64),'e'.repeat(64))];
 row.sourceContextParts=[{partId:'quantity-choice',order:1,role:'quantity-choice-table-row',factPointers:['/typedValue/quantityChoice'],contextCropId:'crop-page-142',source:{book:'DMG',printedPage:142,pdfPage:143,sourceFileSha256:pdfSha},focusBoundsCropPixelsLTRB:[20,25,180,90]},{partId:'gem-base-value',order:2,role:'gem-base-value-and-xp-limit-paragraph',factPointers:['/typedValue/gemBaseValueGpEach'],contextCropId:'crop-page-143',source:{book:'DMG',printedPage:143,pdfPage:144,sourceFileSha256:pdfSha},focusBoundsCropPixelsLTRB:[15,30,190,110]}];
 row.primaryPartIdByFact={'/typedValue/quantityChoice':'quantity-choice','/typedValue/gemBaseValueGpEach':'gem-base-value'};
 const records=collectMonetaryRowIdentityRecords(docs).records,record=records.find(r=>r.uid==='phb-dmg-supplement-row:row-01'),report=auditMonetaryRowIdentity([record]),current=report.records[0];assert.equal(current.contextEvidence.fingerprintVersion,'ordered-source-context-parts-v2');assert.equal(current.contextEvidence.status,'declared-source-context-parts-linked');assert.deepEqual(current.contextEvidence.sourceContextParts.map(p=>[p.source.printedPage,p.source.pdfPage,p.order]),[[142,143,1],[143,144,2]]);assert.ok(current.contextEvidence.sourceContextParts.every(p=>p.sourceRender.coordinateSpace==='original source-render page pixels; top-left origin; [left,top,right,bottom] half-open'&&p.crop.coordinateSpace==='source-page-global source-render pixels; top-left origin; [left,top,right,bottom] half-open'&&p.crop.cropBoundsPixelsCoordinateSpace===p.crop.coordinateSpace&&p.focusCoordinateSpace===`crop-local 300-dpi source-render pixels; left,top,right,bottom; half-open`));assert.equal(current.contextEvidenceSha256,monetaryContextEvidenceFingerprint(current.contextEvidence));const focusSpaceMutation=structuredClone(current.contextEvidence);focusSpaceMutation.sourceContextParts[0].focusCoordinateSpace='source-page-global';assert.notEqual(monetaryContextEvidenceFingerprint(focusSpaceMutation),current.contextEvidenceSha256);assert.equal(current.geometry.filter(g=>g.role==='source-context-part-focus').length,2);assert.ok(current.focusGeometrySha256);
 const reordered=structuredClone(current.contextEvidence);reordered.sourceContextParts.reverse();assert.notEqual(monetaryContextEvidenceFingerprint(reordered),current.contextEvidenceSha256);const missingCrop=structuredClone(current);missingCrop.contextEvidence.sourceContextParts[0].crop={...missingCrop.contextEvidence.sourceContextParts[0].crop,cropSha256:'f'.repeat(64)};missingCrop.contextEvidenceSha256=monetaryContextEvidenceFingerprint(missingCrop.contextEvidence);assert.equal(auditMonetaryRowIdentity([missingCrop]).validation.valid,false);
});

test('ordered source-context parts do not borrow row-focus DPI for an unregistered secondary frame',()=>{
 const docs=minimalDocuments({contextCropId:'unrelated-row-focus',focusBoundsCropPixelsLTRB:[10,10,70,70],coordinateSpace:'crop-local 150-dpi source-render pixels'}),pd=docs.get('phbDmg'),row=pd.data.review.sourceRowsOrClaims[0],pdfSha='a'.repeat(64),crop=(cropId,renderSha,cropSha)=>({groupId:'test',cropId,label:cropId,sourceRender:`${cropId}.png`,sourceRenderSha256:renderSha,sourceRenderDimensionsPx:[800,1000],cropBoundsPixelsLTRB:[100,200,300,400],cropDimensionsPx:[200,200],cropSha256:cropSha});
 row.source={book:'DMG',printedPage:143,pdfPage:144,sourceSha256:pdfSha};row.contextCropId='unrelated-row-focus';row.focus.contextCropId='unrelated-row-focus';row.focus.focusBoundsCropPixelsLTRB=[10,10,70,70];row.typedValue={quantityChoice:'20 jewelry or 50 gems',gemBaseValueGpEach:1000};pd.data.review.evidenceCrops=[crop('unknown-secondary-page','b'.repeat(64),'c'.repeat(64)),crop('unknown-other-page','d'.repeat(64),'e'.repeat(64)),crop('unrelated-row-focus','f'.repeat(64),'1'.repeat(64))];
 row.sourceContextParts=[{partId:'other-page-choice',order:1,role:'quantity-choice-table-row',factPointers:['/typedValue/quantityChoice'],contextCropId:'unknown-primary-page',source:{book:'DMG',printedPage:142,pdfPage:143,sourceFileSha256:pdfSha},focusBoundsCropPixelsLTRB:[20,25,180,90]},{partId:'different-render-value',order:2,role:'gem-base-value-and-xp-limit-paragraph',factPointers:['/typedValue/gemBaseValueGpEach'],contextCropId:'unknown-secondary-page',source:{book:'DMG',printedPage:143,pdfPage:144,sourceFileSha256:pdfSha},focusBoundsCropPixelsLTRB:[15,30,190,110]}];row.primaryPartIdByFact={'/typedValue/quantityChoice':'other-page-choice','/typedValue/gemBaseValueGpEach':'different-render-value'};
 const record=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01'),report=auditMonetaryRowIdentity([record]);assert.equal(report.records[0].contextEvidence.status,'declared-source-context-parts-unassessable');assert.equal(report.validation.valid,false);
});

test('ordered source-context frame registry supplies only exact DPI and rejects conflicting declarations',()=>{
 const frame=loadMonetarySourceRenderFrames().frames.find(item=>item.renderDpi===300);assert.ok(frame);const buildDocs=()=>{const docs=minimalDocuments({contextCropId:'row-focus',focusBoundsCropPixelsLTRB:[10,10,70,70],coordinateSpace:'crop-local 150-dpi source-render pixels'}),pd=docs.get('phbDmg'),row=pd.data.review.sourceRowsOrClaims[0],crop=(cropId,renderSha,cropSha)=>({groupId:'test',cropId,label:cropId,sourceRender:`${cropId}.png`,sourceRenderSha256:renderSha,sourceRenderDimensionsPx:[...frame.sourceRenderDimensionsPx],cropBoundsPixelsLTRB:[100,200,300,400],cropDimensionsPx:[200,200],cropSha256:cropSha});
  row.source={book:frame.book,printedPage:frame.printedPage,pdfPage:frame.pdfPage,sourceSha256:frame.sourcePdfSha256};row.contextCropId='row-focus';row.focus.contextCropId='row-focus';row.typedValue={quantityChoice:'20 jewelry or 50 gems',gemBaseValueGpEach:1000};pd.data.review.evidenceCrops=[crop('registered-secondary-a',frame.sourceRenderSha256,'c'.repeat(64)),crop('registered-secondary-b',frame.sourceRenderSha256,'e'.repeat(64)),crop('row-focus','f'.repeat(64),'1'.repeat(64))];pd.data.review.evidenceCrops[0].sourceCropFrame='CropBox-relative source-render pixel frame; integer bounds are half-open.';row.sourceContextParts=[{partId:'registered-a',order:1,role:'quantity-choice-table-row',factPointers:['/typedValue/quantityChoice'],contextCropId:'registered-secondary-a',source:{book:frame.book,printedPage:frame.printedPage,pdfPage:frame.pdfPage,sourceFileSha256:frame.sourcePdfSha256},focusBoundsCropPixelsLTRB:[20,25,180,90]},{partId:'registered-b',order:2,role:'gem-base-value-and-xp-limit-paragraph',factPointers:['/typedValue/gemBaseValueGpEach'],contextCropId:'registered-secondary-b',source:{book:frame.book,printedPage:frame.printedPage,pdfPage:frame.pdfPage,sourceFileSha256:frame.sourcePdfSha256},focusBoundsCropPixelsLTRB:[15,30,190,110]}];row.primaryPartIdByFact={'/typedValue/quantityChoice':'registered-a','/typedValue/gemBaseValueGpEach':'registered-b'};return {docs,row};};
 const {docs}=buildDocs(),record=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01'),report=auditMonetaryRowIdentity([record]),parts=report.records[0].contextEvidence.sourceContextParts,supplemental=report.records[0].contextEvidence.supplementalContextCrops;assert.equal(report.records[0].contextEvidence.status,'declared-source-context-parts-linked');assert.deepEqual(parts.map(part=>part.sourceRender.renderDpi),[300,300]);assert.ok(parts.every(part=>part.sourceRender.dpiRegistryResolution.status==='matched'));assert.ok(supplemental.every(crop=>crop.sourceRender.coordinateSpace==='original source-render page pixels; top-left origin; [left,top,right,bottom] half-open'&&crop.metadata.coordinateSpace==='source-page-global source-render pixels; top-left origin; [left,top,right,bottom] half-open'&&crop.metadata.cropBoundsPixelsCoordinateSpace===crop.metadata.coordinateSpace));
 const wrongDpi=buildDocs();wrongDpi.row.sourceContextParts[0].sourceRender={renderDpi:150};const wrongDpiRecord=collectMonetaryRowIdentityRecords(wrongDpi.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([wrongDpiRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const wrongIdentity=buildDocs();wrongIdentity.row.sourceContextParts[0].source.book='PHB';const wrongIdentityRecord=collectMonetaryRowIdentityRecords(wrongIdentity.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([wrongIdentityRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const wrongSameCropFocus=buildDocs();wrongSameCropFocus.row.focus.contextCropId='registered-secondary-a';wrongSameCropFocus.row.contextCropId='registered-secondary-a';const wrongSameCropFocusRecord=collectMonetaryRowIdentityRecords(wrongSameCropFocus.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([wrongSameCropFocusRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const nullAlias=buildDocs();nullAlias.row.sourceContextParts[0].source.sourcePdfSha256=null;const nullAliasRecord=collectMonetaryRowIdentityRecords(nullAlias.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([nullAliasRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const multipleDpi=buildDocs();multipleDpi.row.sourceContextParts[0].sourceRender={coordinateSpace:'crop-local 300dpi pixels; metadata also says 150dpi'};const multipleDpiRecord=collectMonetaryRowIdentityRecords(multipleDpi.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([multipleDpiRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const invalidDpi=buildDocs();invalidDpi.row.sourceContextParts[0].sourceRender={coordinateSpace:'crop-local banana-dpi source-render pixels'};const invalidDpiRecord=collectMonetaryRowIdentityRecords(invalidDpi.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([invalidDpiRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const missingDpiToken=buildDocs();missingDpiToken.row.sourceContextParts[0].coordinateSpace='pdf-page points';const missingDpiRecord=collectMonetaryRowIdentityRecords(missingDpiToken.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([missingDpiRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const malformedFrame=buildDocs();malformedFrame.docs.get('phbDmg').data.review.evidenceCrops[0].sourceCropFrame='banana-dpi';const malformedFrameRecord=collectMonetaryRowIdentityRecords(malformedFrame.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([malformedFrameRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable');
 const noFocus=buildDocs();delete noFocus.row.sourceContextParts[0].focusBoundsCropPixelsLTRB;noFocus.row.sourceContextParts[0].factPointers=[];noFocus.row.primaryPartIdByFact={'/typedValue/gemBaseValueGpEach':'registered-b'};const noFocusRecord=collectMonetaryRowIdentityRecords(noFocus.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([noFocusRecord]).records[0].contextEvidence.sourceContextParts[0].focusCoordinateSpace,null);
 for(const rowFocusSpace of [undefined,null,'',false,{},[],'pdf-page points','crop-local banana-dpi source-render pixels']){const malformedFocus=buildDocs();malformedFocus.row.focus.contextCropId='registered-secondary-a';malformedFocus.row.contextCropId='registered-secondary-a';if(rowFocusSpace===undefined)delete malformedFocus.row.focus.coordinateSpace;else malformedFocus.row.focus.coordinateSpace=rowFocusSpace;const malformedFocusRecord=collectMonetaryRowIdentityRecords(malformedFocus.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01');assert.equal(auditMonetaryRowIdentity([malformedFocusRecord]).records[0].contextEvidence.status,'declared-source-context-parts-unassessable',String(rowFocusSpace));}
 const matrixNodes=[['part',({row},part)=>part],['part.focus',({row},part)=>part.focus||=( {})],['part.crop',({row},part)=>part.crop||=( {})],['part.sourceRender',({row},part)=>part.sourceRender||=( {})],['crop',({docs},part)=>docs.get('phbDmg').data.review.evidenceCrops.find(item=>item.cropId===part.contextCropId)],['crop.sourceRender',({docs},part)=>{const crop=docs.get('phbDmg').data.review.evidenceCrops.find(item=>item.cropId===part.contextCropId);crop.sourceRender={sourceRenderId:crop.sourceRender};return crop.sourceRender;}]];
 for(const [nodeName,getNode]of matrixNodes)for(const field of ['renderDpi','sourceRenderDpi','coordinateSpace','sourceCropFrame']){const probe=buildDocs(),part=probe.row.sourceContextParts[0],target=getNode(probe,part);target[field]=field==='renderDpi'||field==='sourceRenderDpi'?150:field==='coordinateSpace'?'crop-local 150-dpi source-render pixels':'source-render page rendered at 150dpi';const candidate=collectMonetaryRowIdentityRecords(probe.docs).records.find(r=>r.uid==='phb-dmg-supplement-row:row-01'),rejected=auditMonetaryRowIdentity([candidate]);assert.equal(rejected.records[0].contextEvidence.status,'declared-source-context-parts-unassessable',`${nodeName}.${field}`);candidate.contextEvidence.status='declared-source-context-parts-linked';candidate.contextEvidenceSha256=monetaryContextEvidenceFingerprint(candidate.contextEvidence);assert.equal(auditMonetaryRowIdentity([candidate]).validation.valid,false,`forged ${nodeName}.${field}`);}
});

test('context label edits do not count as repaired physical source coverage',()=>{
 const pdBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url))),pd=JSON.parse(pdBytes.toString('utf8')),docs=new Map();for(const config of monetaryRowIdentityInputs){let bytes=readFileSync(new URL('../'+config.path,import.meta.url));if(config.key==='ua')bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url)));if(config.key==='phbDmg')bytes=pdBytes;docs.set(config.key,{...config,sha256:hash(bytes),data:JSON.parse(bytes.toString('utf8'))});}
 const crop=docs.get('phbDmg').data.review.evidenceCrops.find(c=>c.cropId==='crop-dmg-high-value-gems-01');crop.label='label-only-changed; crop bytes and bounds are identical';docs.get('phbDmg').sha256=hash(Buffer.from(JSON.stringify(docs.get('phbDmg').data)));
 const f=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-context-crop-findings-extension.json',import.meta.url))).knownFindings.find(f=>f.id==='active-context-crop-partial-glyph-crop-dmg-high-value-gems-01'),recordId=f.records[0].uid.split(':').at(-1),current=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid===f.records[0].uid),snapshot=auditMonetaryRowIdentity([current]),r=snapshot.records[0],review={id:'label-only-context-review',independent:true,disposition:'source-reviewed-repair',supersedes:f.id,evidence,records:[{uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,contextGeometrySha256:r.contextGeometrySha256,contextEvidenceSha256:r.contextEvidenceSha256,contextPhysicalFingerprintVersion:r.contextPhysicalFingerprintVersion,contextPhysicalEvidenceSha256:r.contextPhysicalEvidenceSha256}]};
 assert.ok(recordId);assert.notEqual(r.contextEvidenceSha256,f.records[0].contextEvidenceSha256);const rejected=auditMonetaryRowIdentity([current],{knownFindings:[f],reviews:[review],reviewEvidence});assert.equal(rejected.knownFindings[0].status,'confirmed-source-context-crop-defect');assert.equal(rejected.reviewResults[0].status,'current-explicit-review');
});

test('source context, typed content and exact marker association cannot be cleared by focus-only review',()=>{
 const e=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',import.meta.url)));
 for(const kind of ['source-note-context-defect','typed-content-mismatch','source-marker-association-mismatch']){
  const finding=e.knownFindings.find(f=>f.kind===kind),records=structuredClone(e.records.filter(r=>finding.records.some(f=>f.uid===r.uid)));const current=auditMonetaryRowIdentity(records).records;
  const review={id:'synthetic-dimension-'+kind,independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:current.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256}))};
  assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence}).validation.valid,false);
  if(kind==='source-note-context-defect'){records[0].geometry.find(g=>g.role==='context-crop').bounds[3]+=10;assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding]}).knownFindings[0].status,'context-changed-needs-source-review');}
  if(kind==='typed-content-mismatch'){records[0].recordSha256=hash('changed-source-record');assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding]}).knownFindings[0].status,'content-changed-needs-source-review');}
  if(kind==='source-marker-association-mismatch'){records[0].annotations['/footnoteMarkers']=[...finding.expectedMarkers,'EXTRA'];assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[finding]}).knownFindings[0].status,'confirmed-source-marker-association-mismatch');}
 }
});

test('fifth pair-versus-single qualifier has a separate immutable typed finding on the same placement row',()=>{
 const path='research/source-audit-batch5-monetary-not-gem-qualifier-extension.json',bytes=readFileSync(new URL('../'+path,import.meta.url)),e=JSON.parse(bytes),m=JSON.parse(readFileSync(new URL('../research/monetary-row-identity-findings.json',import.meta.url)));assert.equal(hash(bytes),m.extensions.find(r=>r.path===path).sha256);assert.equal(e.knownFindings.length,1);assert.equal(e.counts.totalKnownFindingRecords,109);assert.equal(e.counts.totalReferencedDistinctRows,193);assert.equal(e.knownFindings[0].confirmedPointers.length,2);
 assert.equal(auditMonetaryRowIdentity(structuredClone(e.records),{knownFindings:e.knownFindings}).knownFindings[0].status,'confirmed-typed-content-mismatch');
});

test('a reviewed qualified representation preserves the unresolved source question and cannot bless unchanged scope',()=>{
 const e=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',import.meta.url))),f=e.knownFindings.find(f=>f.kind==='unresolved-source-scope'),records=structuredClone(e.records.filter(r=>f.records.some(ref=>ref.uid===r.uid)));auditMonetaryRowIdentity(records);
 const frozenRows=JSON.parse(gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url))).toString('utf8')).review.sourceRowsOrClaims,sourceById=new Map(frozenRows.map(row=>[row.sourceRowOrClaimId,row]));for(const r of records){const old=sourceById.get(r.uid.split(':').at(-1));assert.ok(old);r.sourceValueSha256ByPointer=sourceValueHashes(old);}
 const makeReview=()=>({id:'synthetic-qualified-source-scope',independent:true,disposition:'source-reviewed-qualified-representation',supersedes:f.id,evidence,semanticPass:false,underlyingSourceQuestion:{status:'unresolved'},records:records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,recordSha256:r.recordSha256,confirmedPointerSha256:{'/conditions':r.sourceValueSha256ByPointer['/conditions']}}))});
 assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[makeReview()],reviewEvidence}).validation.valid,false);
 for(const r of records){r.recordSha256=hash('synthetic-qualified-representation:'+r.uid);r.sourceValueSha256ByPointer['/conditions']=hash('explicitly scoped but still unresolved:'+r.uid);}const qualified=auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[makeReview()],reviewEvidence});assert.equal(qualified.validation.valid,true);assert.equal(qualified.knownFindings[0].extractionRepresentation,'independently-reviewed-qualified-representation');assert.equal(qualified.knownFindings[0].underlyingSourceQuestion.status,'unresolved');assert.deepEqual(qualified.validation.unresolvedSourceScopeFindingIds,[f.id]);assert.equal(qualified.validation.semanticRowIdentityComplete,false);
 const falseResolution={...makeReview(),underlyingSourceQuestion:{status:'resolved'}};assert.equal(auditMonetaryRowIdentity(records,{knownFindings:[f],reviews:[falseResolution],reviewEvidence}).validation.valid,false);
});

test('three relative money readings and five unresolved Scimitar glyph rows remain explicit without numeric sentinels',()=>{
 const path='research/source-audit-batch5-monetary-retained-uncertainties.json',bytes=readFileSync(new URL('../'+path,import.meta.url)),register=JSON.parse(bytes),manifest=JSON.parse(readFileSync(new URL('../research/monetary-row-identity-findings.json',import.meta.url)));assert.equal(hash(bytes),manifest.retainedUncertainties.sha256);assert.equal(register.uncertainties.length,8);
 const report=auditMonetaryRowIdentity(structuredClone(baseline.records),{retainedUncertainties:register.uncertainties});assert.equal(report.retainedUncertainties.length,8);assert.equal(report.validation.retainedUnresolvedSourceQuestionIds.length,8);assert.ok(report.retainedUncertainties.every(u=>u.semanticPass===false));
 const relative=report.retainedUncertainties.filter(u=>u.kind==='relative-monetary-amount-or-formula-unassessable');assert.equal(relative.length,3);assert.ok(relative.every(u=>u.numericAmountDerived===false&&u.uid.startsWith('source-census-claim:')));
});

test('content or qualified-scope review cannot implicitly adjudicate unrelated duplicate focus evidence',()=>{
 const f=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus'),records=recordsFor([f]),before=auditMonetaryRowIdentity(records),refs=before.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256})),review={id:'synthetic-content-only-review',independent:true,disposition:'source-reviewed-repair',evidence,records:refs};
 const untouched=auditMonetaryRowIdentity(records,{reviews:[review],reviewEvidence});assert.equal(untouched.reviewResults[0].status,'current-explicit-review');assert.equal(untouched.duplicateCandidates[0].status,'candidate-requires-source-review');
 const explicitlyScoped={...review,adjudicatesDuplicateCandidateIds:[before.duplicateCandidates[0].id]};assert.equal(auditMonetaryRowIdentity(records,{reviews:[explicitlyScoped],reviewEvidence}).duplicateCandidates[0].status,'source-reviewed-repair');
 const scopeReview={...explicitlyScoped,disposition:'source-reviewed-qualified-representation',semanticPass:false,underlyingSourceQuestion:{status:'unresolved'}};assert.equal(auditMonetaryRowIdentity(records,{reviews:[scopeReview],reviewEvidence}).duplicateCandidates[0].status,'candidate-requires-source-review');
});

function oneFrozenUaContextRow(recordId){
 recordId=String(recordId).split(':').at(-1);const bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url))),source=JSON.parse(bytes.toString('utf8')),row=source.rowRecords.find(r=>r.recordId===recordId),groupId=recordId.match(/^(ua-other-\d+)/)?.[1],group=source.groupReviews.find(g=>g.groupId===groupId),docs=minimalDocuments({contextCropId:'crop',focusBoundsCropPixelsLTRB:[1,2,10,12]});
 docs.get('ua').sha256=hash(bytes);docs.get('ua').data={...source,groupReviews:[group],rowRecords:[row]};return {docs,row,group,source};
}
function linkUaContext(record,{changeFocus=false,changeLegacyContext=false}={}){
 const e=record.contextEvidence,segment=e.legacyProjection.rowContext.segmentId,old=e.legacyProjection.sourceEvidenceIndex.find(entry=>entry.segmentId===segment),uid=record.id,renderSha=old?.pageImageSha256||'c'.repeat(64),renderDims=old?.pageDimensionsPx||[1000,1200],pdfSha=record.source.sourceSha256,targetId='target-'+uid;
 const sourceRender={sourceRenderId:'native-render-'+uid,sourceRenderSha256:renderSha,sourceRenderDimensionsPx:renderDims,renderDpi:180,coordinateSpace:'source-render pixels, top-left origin'};
 const crop={cropBoundsPdfPagePointsTopLeftLTRB:[1,1,100,100],cropBoundsPixelsLTRB:[1,1,101,101],cropDimensionsPx:[100,100],cropSha256:'b'.repeat(64),renderDpi:180,coordinateSpace:'source-render pixels, top-left origin, LTRB half-open'};
 e.status='declared-active-context-targets-linked';e.activeTargetStatus='declared-active-context-targets-linked';e.declaredLinks=[{targetId,targetOrder:1,role:'table-context',segmentId:segment}];e.crops=[{cropId:targetId,targetOrder:1,role:'table-context',segmentId:segment,source:{book:'UA',sourcePdfSha256:pdfSha,printedPage:record.source.printedPage,pdfPage:record.source.pdfPage},sourceRender,metadata:{sourcePdfSha256:pdfSha,sourceRenderSha256:renderSha,sourceRenderDimensionsPx:renderDims,cropBoundsPdfPagePointsTopLeft:crop.cropBoundsPdfPagePointsTopLeftLTRB,cropBoundsPixelsLTRB:crop.cropBoundsPixelsLTRB,cropDimensionsPx:crop.cropDimensionsPx,cropSha256:crop.cropSha256,renderDpi:180,coordinateSpace:crop.coordinateSpace,sourceCrop:crop,pixelReview:{status:'independent-pixel-review-recorded'}}}];
 if(changeLegacyContext){const g=record.geometry.find(g=>g.role==='context-crop');g.bounds[2]+=2;}
 if(changeFocus){const g=record.geometry.find(g=>g.role==='row-focus');g.bounds[2]+=2;}
 record.contextEvidenceSha256=monetaryContextEvidenceFingerprint(e);return record;
}

test('original583 and179 gzip inputs replay the same focus and legacy-context geometry hashes',()=>{
 const uaBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-ua-583-before.json.gz',import.meta.url))),pdBytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-source-phbdmg-179-before.json.gz',import.meta.url)));
 assert.equal(hash(uaBytes),'8ec8fcb1c937f1e5fdc86af87029a8defd1a4e9ee27c44ef9d0d84eef7e4577a');assert.equal(hash(pdBytes),'b0d46959c44e0d156ef5d40326af48c1f1ce9ee5b282a870c06c41010b94dcc9');
 const docs=new Map(monetaryRowIdentityInputs.map(c=>[c.key,{...c,sha256:hash(readFileSync(new URL('../'+c.path,import.meta.url))),data:JSON.parse(readFileSync(new URL('../'+c.path,import.meta.url)))}]));
 docs.set('ua',{...docs.get('ua'),sha256:hash(uaBytes),data:JSON.parse(uaBytes.toString('utf8'))});docs.set('phbDmg',{...docs.get('phbDmg'),sha256:hash(pdBytes),data:JSON.parse(pdBytes.toString('utf8'))});
 const records=auditMonetaryRowIdentity(collectMonetaryRowIdentityRecords(docs).records).records,oldByUid=new Map(baseline.records.map(r=>[r.uid,r])),ctxRoles=new Set(['context-crop','page-context','editorial-comparator-context']);
 const legacySurfaces=new Set(['ua-supplement-row','phb-dmg-supplement-row','phb-reference-row-comparison']);let checked=0;
 for(const record of records.filter(r=>legacySurfaces.has(r.surface))){const old=oldByUid.get(record.uid);assert.ok(old,record.uid);const oldContext=hash(old.geometry.filter(g=>ctxRoles.has(g.role)).map(({space,bounds,source,frame,role})=>({space,bounds,source,frame,role})));assert.equal(record.focusGeometrySha256,old.focusGeometrySha256,record.uid);assert.equal(record.contextGeometrySha256,oldContext,record.uid);assert.equal(record.geometry.length,old.geometry.length,record.uid);checked++;}
 assert.equal(checked,927);
 const report=auditMonetaryRowIdentity(records);assert.equal(report.contextEvidenceCoverage.records,927);assert.deepEqual(report.contextEvidenceCoverage.recordsBySurface,{'ua-supplement-row':583,'phb-dmg-supplement-row':179,'phb-reference-row-comparison':165});assert.deepEqual(report.contextEvidenceCoverage.statusBySurface['ua-supplement-row'],{'legacy-declared-context-metadata;active-targets-unassessed':583});assert.equal(report.contextEvidenceCoverage.uniqueCropIds,31);assert.equal(report.contextEvidenceCoverage.uniqueSourcePdfPageFrames,32);
 const beforeBytes=readFileSync(new URL('../research/source-audit-batch5-monetary-context-assets-before-count-fix.json',import.meta.url));assert.equal(hash(beforeBytes),'721e4f2f40ea50a5d30e61d78acb4a93c729134b581ef405a61bc7053d5ff8c1');const before=JSON.parse(beforeBytes.toString('utf8'));assert.equal(before.originalSourceProjection.completeUniqueCropIds,31);assert.equal(before.originalSourceProjection.uniqueSourcePdfPageFrames,32);assert.equal(before.v3Projection.legacyCropsOnlyUniqueCropIds,34);assert.equal(before.v3Projection.completeUniqueCropIds,35);assert.equal(before.v3Projection.oldDiagnosticUniqueCropIds,34);assert.deepEqual(before.v3Projection.omittedFromLegacyCropCount,['crop-dmg-gem-and-magic-treasure-valuations-01']);
 const v3Bytes=gunzipSync(readFileSync(new URL('./fixtures/monetary-phbdmg-v3-index-candidate.json.gz',import.meta.url))),v3Data=JSON.parse(v3Bytes.toString('utf8')),v3Docs=new Map(docs);v3Docs.set('phbDmg',{...docs.get('phbDmg'),path:'tests/fixtures/monetary-phbdmg-v3-index-candidate.json.gz#decompressed-candidate',sha256:hash(v3Bytes),data:v3Data});const v3Records=collectMonetaryRowIdentityRecords(v3Docs).records,v3Report=auditMonetaryRowIdentity(v3Records);assert.equal(v3Records.length,2161);assert.equal(v3Report.contextEvidenceCoverage.records,927);assert.equal(v3Report.contextEvidenceCoverage.uniqueCropIds,35);assert.equal(v3Report.contextEvidenceCoverage.uniqueSourcePdfPageFrames,33);const v3Wand=v3Records.find(r=>r.uid==='phb-dmg-supplement-row:dmg-wand-of-wonder-gems-88-90');assert.ok(v3Wand.contextEvidence.supplementalContextCrops.some(c=>c.cropId==='crop-dmg-gem-and-magic-treasure-valuations-01'));
});

test('legacy UA context migration stays pending until a valid changed context and independent current-frame review',()=>{
 const extension=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',import.meta.url))),finding=extension.knownFindings.find(f=>f.id==='ua-misc-note-context-ua-other-005-E2-r063'),{docs}=oneFrozenUaContextRow(finding.records[0].uid),record=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid===finding.records[0].uid),unbridged=auditMonetaryRowIdentity([structuredClone(record)],{knownFindings:[finding]});
 assert.equal(unbridged.knownFindings[0].status,'context-evidence-reference-missing-needs-source-review');
 const pref=auditMonetaryRowIdentity([structuredClone(record)]).records[0],old=finding.records[0],bridgeEntry={findingId:finding.id,uid:old.uid,oldRowIdentitySha256:old.rowIdentitySha256,oldFocusGeometrySha256:old.focusGeometrySha256,oldContextGeometrySha256:old.contextGeometrySha256,newContextEvidenceSha256:pref.contextEvidenceSha256,newContextFingerprintVersion:uaContextFingerprintVersion,newContextPhysicalFingerprintVersion:pref.contextPhysicalFingerprintVersion,newContextPhysicalEvidenceSha256:pref.contextPhysicalEvidenceSha256},bridge=new Map([[`${finding.id}:${old.uid}`,bridgeEntry]]);
 const migrated=auditMonetaryRowIdentity([structuredClone(record)],{knownFindings:[finding],contextMigrationBridgeEntries:bridge});assert.equal(migrated.knownFindings[0].status,'legacy-context-migration-baseline-pending-source-repair');assert.equal(migrated.validation.valid,false);
 const repaired=linkUaContext(structuredClone(pref),{changeFocus:true,changeLegacyContext:true}),after=auditMonetaryRowIdentity([repaired],{knownFindings:[finding],contextMigrationBridgeEntries:bridge});assert.equal(after.knownFindings[0].status,'context-changed-needs-source-review');
 const current=after.records[0],review={id:'independent-current-UA-context-repair',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:[{uid:current.uid,rowIdentitySha256:current.rowIdentitySha256,focusGeometrySha256:current.focusGeometrySha256,contextGeometrySha256:current.contextGeometrySha256,contextEvidenceSha256:current.contextEvidenceSha256,contextPhysicalFingerprintVersion:current.contextPhysicalFingerprintVersion,contextPhysicalEvidenceSha256:current.contextPhysicalEvidenceSha256}]};
 const accepted=auditMonetaryRowIdentity([repaired],{knownFindings:[finding],reviews:[review],reviewEvidence,contextMigrationBridgeEntries:bridge});assert.equal(accepted.reviewResults[0].status,'current-explicit-review');assert.equal(accepted.knownFindings[0].status,'explicit-source-reviewed-repair');
});

test('a legacy migration bridge cannot approve missing, invalid, unchanged or incompletely reviewed context',()=>{
 const extension=JSON.parse(readFileSync(new URL('../research/source-audit-batch5-monetary-row-identity-complete-qa-extension.json',import.meta.url))),finding=extension.knownFindings.find(f=>f.id==='ua-misc-note-context-ua-other-005-E2-r063'),{docs}=oneFrozenUaContextRow(finding.records[0].uid),record=collectMonetaryRowIdentityRecords(docs).records.find(r=>r.uid===finding.records[0].uid),pref=auditMonetaryRowIdentity([structuredClone(record)]).records[0],old=finding.records[0],entry={findingId:finding.id,uid:old.uid,oldRowIdentitySha256:old.rowIdentitySha256,oldFocusGeometrySha256:old.focusGeometrySha256,oldContextGeometrySha256:old.contextGeometrySha256,newContextEvidenceSha256:pref.contextEvidenceSha256,newContextFingerprintVersion:uaContextFingerprintVersion,newContextPhysicalFingerprintVersion:pref.contextPhysicalFingerprintVersion,newContextPhysicalEvidenceSha256:pref.contextPhysicalEvidenceSha256},bridge=new Map([[`${finding.id}:${old.uid}`,entry]]);
 const unchanged=structuredClone(pref),unchangedReport=auditMonetaryRowIdentity([unchanged],{knownFindings:[finding],contextMigrationBridgeEntries:bridge});assert.equal(unchangedReport.knownFindings[0].status,'legacy-context-migration-baseline-pending-source-repair');
 const missing=structuredClone(pref);delete missing.contextEvidence;const missingReport=auditMonetaryRowIdentity([missing],{knownFindings:[finding],contextMigrationBridgeEntries:bridge});assert.equal(missingReport.knownFindings[0].status,'current-context-evidence-missing-needs-source-review');
 const invalid=linkUaContext(structuredClone(pref));invalid.contextEvidence.crops[0].metadata.cropDimensionsPx[0]++;invalid.contextEvidenceSha256=monetaryContextEvidenceFingerprint(invalid.contextEvidence);const invalidAudit=auditMonetaryRowIdentity([invalid],{knownFindings:[finding],contextMigrationBridgeEntries:bridge}),current=invalidAudit.records[0],review={id:'fresh-but-invalid-UA-context-review',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence,records:[{uid:current.uid,rowIdentitySha256:current.rowIdentitySha256,focusGeometrySha256:current.focusGeometrySha256,contextGeometrySha256:current.contextGeometrySha256,contextEvidenceSha256:current.contextEvidenceSha256,contextPhysicalFingerprintVersion:current.contextPhysicalFingerprintVersion,contextPhysicalEvidenceSha256:current.contextPhysicalEvidenceSha256}]};
 const rejected=auditMonetaryRowIdentity([invalid],{knownFindings:[finding],reviews:[review],reviewEvidence,contextMigrationBridgeEntries:bridge});assert.equal(rejected.reviewResults[0].status,'current-explicit-review');assert.equal(rejected.knownFindings[0].status,'current-context-evidence-unassessable-needs-source-review');
 const wrongBridge=new Map([[`${finding.id}:${old.uid}`,{...entry,oldContextGeometrySha256:'f'.repeat(64)}]]),tampered=auditMonetaryRowIdentity([structuredClone(pref)],{knownFindings:[finding],contextMigrationBridgeEntries:wrongBridge});assert.equal(tampered.knownFindings[0].status,'context-evidence-reference-missing-needs-source-review');
});
