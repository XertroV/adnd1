import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const capture='/tmp/pd-dpi-independent-review/full-class-before-c63',repo='/workspace/adnd1';
const sha=b=>createHash('sha256').update(b).digest('hex');
const artifact=p=>{const b=readFileSync(p.startsWith('/')?p:repo+'/'+p);return {path:p,sha256:sha(b),data:JSON.parse(b)}};
const {buildMonetarySourceIndex}=await import(pathToFileURL(capture+'/tools/monetary-source-inventory.mjs'));
const {collectMonetaryRowIdentityRecords,auditMonetaryRowIdentity,monetaryRowIdentityInputs}=await import(pathToFileURL(capture+'/tools/monetary-row-identity-audit.mjs'));
const candidate=artifact('/tmp/batch5-phbdmg-money-corrections-v5/proposal-v5/phb-dmg-additional-prices-correction-candidate-v5.json');
if(candidate.sha256!=='e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6')throw Error('candidate changed');
const paths={canonical:'research/price-source-inventory.json',equipment:'equipment.json',equipmentBindings:'research/equipment-source-row-bindings.json',uaSupplement:'research/source-audit-batch5-ua-additional-prices.json',uaDescriptionSupplement:'research/source-audit-batch5-price-description-records.json',priceDiscoverySupplement:'research/source-audit-batch5-price-discovery-reconciliation.json',phbDmgPricePassageSupplement:'research/source-audit-batch5-phb-dmg-price-passage-records.json'};
const fullInputs=Object.fromEntries(Object.entries(paths).map(([k,p])=>[k,artifact(p)]));
const fullDocs=new Map(monetaryRowIdentityInputs.filter(c=>c.key!=='phbDmg').map(c=>[c.key,{...c,...artifact(c.path)}]));
const emptyData={canonical:{sourceInventories:[],siteClaims:[],sourcePageCensuses:[],fieldEvidenceBindings:[]},ua:{...fullDocs.get('ua').data,rowRecords:[],groupReviews:[]},passages:{records:[]},descriptions:{...fullDocs.get('descriptions').data,newSourceDescriptionRecords:[],pointerResolutionLinks:[]},receipts:{claimReceipts:[]},phbDmgCensus:{records:[]},uaCensus:{records:[]},monsterCensus:{claims:[]}};
const miniArtifact=(original,data)=>({...original,path:original.path+'#bounded-empty-copy',sha256:sha(JSON.stringify(data)),data});
const miniDocs=new Map([...fullDocs].map(([k,d])=>[k,miniArtifact(d,emptyData[k]??d.data)]));
emptyData.descriptions.inputSupplement={...emptyData.descriptions.inputSupplement,sha256:miniDocs.get('ua').sha256};miniDocs.set('descriptions',miniArtifact(fullDocs.get('descriptions'),emptyData.descriptions));
const miniInputs={...fullInputs,canonical:miniDocs.get('canonical'),equipment:miniArtifact(fullInputs.equipment,[]),equipmentBindings:miniArtifact(fullInputs.equipmentBindings,{bindings:[]}),uaSupplement:miniDocs.get('ua'),uaDescriptionSupplement:miniDocs.get('descriptions'),priceDiscoverySupplement:miniDocs.get('receipts'),phbDmgPricePassageSupplement:miniDocs.get('passages')};
const rowId='dmg-poison-ingestive-c';
const slim=data=>({...data,review:{...data.review,sourceRowsOrClaims:data.review.sourceRowsOrClaims.filter(r=>r.sourceRowOrClaimId===rowId)},additionalReferenceSheetReview:{...data.additionalReferenceSheetReview,rowComparisons:[]}});
const seed=candidate.data;
function run(data,{full=false}={}){
 const pd={path:candidate.path+'#bounded-declaration-matrix',sha256:sha(JSON.stringify(data)),data};
 const index=buildMonetarySourceIndex({...fullInputs,phbDmgSupplement:pd},{});
 const docs=new Map(fullDocs);docs.set('phbDmg',{...monetaryRowIdentityInputs.find(c=>c.key==='phbDmg'),...pd});
 const records=collectMonetaryRowIdentityRecords(docs).records;
 return {index,records};
}
const nominalFull=run(candidate.data,{full:true}),nominal=run(seed);
const findI=r=>r.index.sourceOccurrences.find(r=>r.sourceOccurrenceId==='phb-dmg:'+rowId);
const findR=r=>r.records.find(r=>r.uid==='phb-dmg-supplement-row:'+rowId);
const nominalClaimIds=findI(nominal).valueClaimIds;
const target=data=>{const row=data.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId===rowId),part=row.sourceContextParts[1],crop=data.review.evidenceCrops.find(c=>c.cropId===part.contextCropId);return {row,part,crop}};
const canonical=dpi=>`crop-local ${dpi}-dpi source-render pixels; left,top,right,bottom; half-open`;
const nodes=['part','part.focus','part.crop','part.sourceRender','crop','crop.sourceRender'];
const fields=['renderDpi','sourceRenderDpi','coordinateSpace','sourceCropFrame'];
const numberClasses=[['absent',undefined,'valid'],['agreeing-integer',300,'valid'],['conflicting-integer',150,'reject'],['zero',0,'reject'],['negative',-300,'reject'],['fraction',300.5,'reject'],['numeric-string','300','reject'],['null',null,'reject'],['boolean',true,'reject'],['empty-string','','reject'],['object',{dpi:300},'reject'],['array',[300],'reject']];
const spaceClasses=field=>[['absent',undefined,'valid'],['agreeing-dpi',field==='coordinateSpace'?canonical(300):'PyMuPDF CropBox-relative PageRect rendered at 300dpi','valid'],['conflicting-dpi',field==='coordinateSpace'?canonical(150):'PyMuPDF CropBox-relative PageRect rendered at 150dpi','reject'],['zero-dpi','crop-local 0-dpi source-render pixels','reject'],['negative-dpi','crop-local -300-dpi source-render pixels','reject'],['fractional-dpi','crop-local 300.5-dpi source-render pixels','reject'],['no-dpi-description',field==='coordinateSpace'?'pdf-page points':'PyMuPDF CropBox-relative PageRect',field==='coordinateSpace'?'reject':'valid'],['malformed-dpi','crop-local banana-dpi source-render pixels','reject'],['repeated-agreeing-dpi','300dpi; same frame rendered at 300dpi',field==='coordinateSpace'?'observe':'valid'],['multiple-conflicting-dpi','300dpi; contradictory frame rendered at 150dpi','reject'],['numeric-string','300',field==='coordinateSpace'?'reject':'valid'],['null',null,'reject'],['boolean',true,'reject'],['empty-string','','reject'],['object',{dpi:300},'reject'],['array',[300],'reject']];
function nodeObject(x,node,{absent=false}={}){
 if(node==='part')return x.part;if(node==='crop')return x.crop;
 const [owner,key]=node.split('.'),parent=x[owner];
 if(absent)return parent[key]&&typeof parent[key]==='object'?parent[key]:null;
 if(node==='part.sourceRender')return parent[key]={sourceRenderId:x.crop.sourceRender,sourceRenderSha256:x.crop.sourceRenderSha256,sourceRenderDimensionsPx:x.crop.sourceRenderDimensionsPx,renderDpi:300};
 if(node==='crop.sourceRender')return parent[key]={sourceRenderId:x.crop.sourceRender,sourceRenderSha256:x.crop.sourceRenderSha256,sourceRenderDimensionsPx:x.crop.sourceRenderDimensionsPx,renderDpi:300};
 return parent[key]={};
}
const cases=[];
for(const node of nodes)for(const field of fields)for(const [valueClass,value,policy]of field.endsWith('Dpi')?numberClasses:spaceClasses(field))cases.push({kind:'node-field-value',node,field,valueClass,value,expected:node==='crop.sourceRender'&&valueClass!=='absent'?'reject':policy});
for(const [valueClass,value,policy]of spaceClasses('coordinateSpace'))cases.push({kind:'same-crop-row-focus',node:'row.focus',field:'coordinateSpace',valueClass,value:valueClass==='agreeing-dpi'?canonical(150):valueClass==='conflicting-dpi'?canonical(300):valueClass==='repeated-agreeing-dpi'?'150dpi; same frame rendered at 150dpi':value,expected:valueClass==='absent'?'reject':policy});
const confirmations=[];
for(const c of cases.filter(c=>c.kind==='same-crop-row-focus'&&['boolean','object','array'].includes(c.valueClass))){
 const data=structuredClone(seed);target(data).row.focus.coordinateSpace=structuredClone(c.value);const pd={path:candidate.path+'#throw-index-confirmation',sha256:sha(JSON.stringify(data)),data};const i=buildMonetarySourceIndex({...fullInputs,phbDmgSupplement:pd});const r=i.sourceOccurrences.find(r=>r.sourceOccurrenceId==='phb-dmg:'+rowId);confirmations.push({...c,indexStatus:r.evidence.sourceContextPartsStatus,indexReason:r.evidence.sourceContextPartsReason,claimsRetained:JSON.stringify(r.valueClaimIds)===JSON.stringify(nominalClaimIds),partsRetained:r.evidence.sourceContextParts.length===2});
}
writeFileSync(capture+'/row-throw-index-confirmations.json',JSON.stringify({scope:'Index-only completion for the three row-collector type exceptions in the same bounded matrix.',confirmations},null,2)+'\n');console.log(JSON.stringify(confirmations.map(c=>[c.valueClass,c.indexStatus,c.claimsRetained,c.partsRetained])));
