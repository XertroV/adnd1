import {readFileSync} from 'node:fs';
import {auditMonetaryRowIdentity,hash} from './tools/monetary-row-identity-audit.mjs';
const fixture=JSON.parse(readFileSync(new URL('./tests/fixtures/monetary-row-identity-before.json',import.meta.url)));
const finding=fixture.knownFindings.find(f=>f.kind==='duplicate-wrong-row-focus');
const records=structuredClone(fixture.records.filter(r=>finding.records.some(ref=>ref.uid===r.uid)));
for(let i=0;i<records.length;i++){
 const record=records[i];
 for(const geometry of record.geometry.filter(g=>g.role==='row-focus'&&g.space==='pdf-page-points'))geometry.bounds=[350,130,550,150];
 const primary=record.geometry.find(g=>g.role==='row-focus'&&g.space==='pdf-page-points');
 record.geometry.push({role:'source-context-part-focus',space:'pdf-page-points',source:structuredClone(primary.source),frame:primary.frame,bounds:i===0?[270,190,430,215]:[650,190,810,215],validShape:true,path:`/synthetic/note-${i}`});
}
const preliminary=auditMonetaryRowIdentity(records);
const evidenceBytes=Buffer.from('synthetic executable regression fixture');
const review={id:'before-e99-same-primary-different-notes',independent:true,disposition:'source-reviewed-repair',supersedes:finding.id,evidence:{path:'private-before-counterexample',sha256:hash(evidenceBytes)},records:preliminary.records.map(r=>({uid:r.uid,rowIdentitySha256:r.rowIdentitySha256,focusGeometrySha256:r.focusGeometrySha256,focusPhysicalFingerprintVersion:r.focusPhysicalFingerprintVersion,focusPhysicalGeometrySha256:r.focusPhysicalGeometrySha256,contextGeometrySha256:r.contextGeometrySha256,recordSha256:r.recordSha256,annotationSha256:r.annotationSha256}))};
const report=auditMonetaryRowIdentity(records,{knownFindings:[finding],reviews:[review],reviewEvidence:new Map([['private-before-counterexample',evidenceBytes]])});
const result={findingId:finding.id,status:report.knownFindings[0].status,reviewStatus:report.reviewResults[0].status,primaryWindows:report.records.map(r=>r.geometry.filter(g=>g.role==='row-focus'&&g.space==='pdf-page-points').map(g=>g.bounds)),appendedNoteWindows:report.records.map(r=>r.geometry.filter(g=>g.role==='source-context-part-focus').map(g=>g.bounds)),candidateStatuses:report.duplicateCandidates.map(c=>c.status)};
console.log(JSON.stringify(result,null,2));
if(result.status!=='explicit-source-reviewed-repair')process.exitCode=1;
