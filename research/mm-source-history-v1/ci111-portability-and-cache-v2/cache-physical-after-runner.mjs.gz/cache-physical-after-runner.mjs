import * as fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='/workspace/adnd1-next-source-native';
const out='/workspace/vault-audit-private/pass8/root/mm-cache-physical-freshness-after-v4';
const sha=b=>createHash('sha256').update(b).digest('hex');
const currentReader=path.join(root,'research/mm-source-history-v1/closed-version29-reader-current-mm-v1.mjs');
const probe='/workspace/research/mm-next-source-epoch-guard-plan-v1/v4/closed-version29-reader-current-mm-v4-probe.mjs';
const bridgePath='research/mm-source-history-v1/mm-to-historical-h-v1.json';
const bridge=JSON.parse(fs.readFileSync(path.join(root,bridgePath),'utf8'));
const strict=bridge.sourceEpoch.strictGuard;
const extra=Array.isArray(strict.codeFiles)?strict.codeFiles.map(x=>x.path):Object.keys(strict.codeFiles||{});
const codePaths=['tools/mm-current-source-gate-v1.mjs','tests/helpers/mm-treasure-current-m1-cohort-v2.mjs','tests/helpers/mm-treasure-current-m1-cohort-factory-v2.mjs'];
const contractPaths=[bridgePath,'research/hirelings-source-epoch-proposal-v5/closed-version29-reader-actual-hired-v2.json',bridge.historicalH.fixturePath];
const rawPaths=Object.keys(strict.rawInputs),additionalPaths=Object.keys(strict.selectedAdditionalInputs);
const nativeFixture=strict.fixturePath;
assert.equal(typeof nativeFixture,'string');assert.equal(rawPaths.length,9);assert.equal(additionalPaths.length,12);
const remaining=bridge.mappingPolicy.orderedFiles.map(x=>x.path).filter(p=>!rawPaths.includes(p)&&!additionalPaths.includes(p));
const plan=[...rawPaths.map(p=>({path:p,lane:'raw9'})),...additionalPaths.map(p=>({path:p,lane:'additional12'})),...codePaths.map(p=>({path:p,lane:'guard-code'})),...contractPaths.map(p=>({path:p,lane:'bridge-H-contract-fixture'})),...remaining.map(p=>({path:p,lane:'additional-mapped-path',callPath:p})),{path:nativeFixture,lane:'native-cohort-fixture',compareActive:true}];
assert.equal(new Set(plan.map(x=>x.path)).size,plan.length);
const allPaths=[...new Set([...plan.map(x=>x.path),currentReader.slice(root.length+1)])];
function id(p){const b=fs.readFileSync(path.join(root,p));const st=fs.statSync(path.join(root,p));return {path:p,sha256:sha(b),bytes:b.length,ino:st.ino,mode:st.mode};}
const before=allPaths.map(id);
const trackedGitStatusBefore=execFileSync('git',['-C',root,'status','--porcelain','--untracked-files=no'],{encoding:'utf8'});
const result={schemaVersion:1,artifactType:'actual-root-warm-cache-physical-freshness-after-v4-native-fixture-check',startedAt:new Date().toISOString(),head:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),activeReader:{path:currentReader,sha256:sha(fs.readFileSync(currentReader))},probe:{path:probe,sha256:sha(fs.readFileSync(probe))},mutationRecipe:'append one newline to private mutant; atomically rename original file to private backup and mutant to original path; always remove mutant and rename exact original inode back in finally; no source values or persistent files changed',before,checks:[],physicalMutations:true,installed:false,trackedGitStatusBefore};
const report=path.join(out,'physical-freshness-after-v4.json');
const save=()=>fs.writeFileSync(report,JSON.stringify(result,null,2)+'\n');save();
fs.writeFileSync(path.join(out,'native-fixture-original.json'),fs.readFileSync(path.join(root,nativeFixture)));
const candidate=await import(pathToFileURL(probe).href);
const active=await import(pathToFileURL(currentReader).href);
const rulesBytes=fs.readFileSync(path.join(root,'rules.json'));
const expected=candidate.normalizeVersion29HistoricalBytes('rules.json',rulesBytes);
assert.equal(sha(active.normalizeVersion29HistoricalBytes('rules.json',rulesBytes)),sha(expected));
for(let index=0;index<plan.length;index++){
 const row=plan[index],target=path.join(root,row.path),original=fs.readFileSync(target),callPath=row.callPath||'rules.json',caller=callPath==='rules.json'?rulesBytes:fs.readFileSync(path.join(root,callPath));
 const originalStat=fs.statSync(target),backup=path.join(out,`in-progress-original-${index}.bin`),temp=target+`.root-cache-freshness-mutant-${process.pid}`;
 assert.equal(fs.existsSync(backup),false);assert.equal(fs.existsSync(temp),false);
 const check={index,path:row.path,lane:row.lane,callPath,originalSha256:sha(original),mutantSha256:sha(Buffer.concat([original,Buffer.from('\n')]))};
 result.inProgress={...check,backup,temp};save();
 let moved=false,mutated=false;
 try{
  fs.writeFileSync(temp,Buffer.concat([original,Buffer.from('\n')]),{flag:'wx',mode:originalStat.mode});
  fs.renameSync(target,backup);moved=true;
  fs.renameSync(temp,target);mutated=true;
  try{const got=candidate.normalizeVersion29HistoricalBytes(callPath,caller);check.candidateRejected=false;check.acceptedOutputSha256=sha(got);}catch(e){check.candidateRejected=true;check.candidateError=e.message;}
  if(row.compareActive){try{const got=active.normalizeVersion29HistoricalBytes(callPath,caller);check.active493Rejected=false;check.activeAcceptedOutputSha256=sha(got);}catch(e){check.active493Rejected=true;check.activeError=e.message;}}
 }finally{
  if(mutated&&fs.existsSync(target))fs.unlinkSync(target);
  if(moved)fs.renameSync(backup,target);
  if(fs.existsSync(temp))fs.unlinkSync(temp);
  assert.equal(sha(fs.readFileSync(target)),sha(original),'exact restored bytes');assert.equal(fs.statSync(target).ino,originalStat.ino,'exact original inode restored');
  check.restoredBytesAndInode=true;
 }
 try{candidate.normalizeVersion29HistoricalBytes(callPath,caller);check.afterRestorePositive=true;}catch(e){check.afterRestorePositive=false;check.afterRestoreError=e.message;}
 result.checks.push(check);delete result.inProgress;save();
}
result.after=allPaths.map(id);assert.deepEqual(result.after,before,'all physical inputs exact after window');
result.trackedGitStatus=execFileSync('git',['-C',root,'status','--porcelain','--untracked-files=no'],{encoding:'utf8'});assert.equal(result.trackedGitStatus,trackedGitStatusBefore,'tracked status is exact before/after, including root-owned portable-test edit');
result.endedAt=new Date().toISOString();result.candidateRejectedCount=result.checks.filter(x=>x.candidateRejected).length;result.candidateUnexpectedAcceptances=result.checks.filter(x=>!x.candidateRejected).map(x=>x.path);result.status=result.candidateUnexpectedAcceptances.length?'detected-warm-freshness-gap; exact physical inputs restored':'all-physical-stale-inputs-rejected; exact physical inputs restored';assert.equal(result.candidateRejectedCount,result.checks.length,'all39 must reject afternativefixturefix');save();console.log(JSON.stringify({report,sha256:sha(fs.readFileSync(report)),cases:result.checks.length,rejected:result.candidateRejectedCount,unexpectedAccepted:result.candidateUnexpectedAcceptances,restored:result.checks.every(x=>x.restoredBytesAndInode&&x.afterRestorePositive),trackedGitStatusPreserved:result.trackedGitStatus===trackedGitStatusBefore,elapsedSeconds:(new Date(result.endedAt)-new Date(result.startedAt))/1000}));
