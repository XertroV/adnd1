import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const capture=process.env.REVIEW_AFTER_CAPTURE,repo='/workspace/adnd1';
if(!capture)throw Error('REVIEW_AFTER_CAPTURE is required');
const sha=b=>createHash('sha256').update(b).digest('hex');
const captureManifest=JSON.parse(readFileSync(capture+'/capture-manifest.json'));
for(const f of captureManifest.files)if(sha(readFileSync(capture+'/'+f.path))!==f.sha256)throw Error('Captured dependency changed: '+f.path);
const artifact=p=>{const b=readFileSync(p.startsWith('/')?p:repo+'/'+p);return {path:p,sha256:sha(b),data:JSON.parse(b)}};
const {buildMonetarySourceIndex}=await import(pathToFileURL(capture+'/tools/monetary-source-inventory.mjs'));
const {collectMonetaryRowIdentityRecords,auditMonetaryRowIdentity,monetaryRowIdentityInputs}=await import(pathToFileURL(capture+'/tools/monetary-row-identity-audit.mjs'));
const candidate=artifact('/tmp/batch5-phbdmg-money-corrections-v5/proposal-v5/phb-dmg-additional-prices-correction-candidate-v5.json');
if(candidate.sha256!=='e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6')throw Error('candidate changed');
const paths={canonical:'research/price-source-inventory.json',equipment:'equipment.json',equipmentBindings:'research/equipment-source-row-bindings.json',uaSupplement:'research/source-audit-batch5-ua-additional-prices.json',uaDescriptionSupplement:'research/source-audit-batch5-price-description-records.json',priceDiscoverySupplement:'research/source-audit-batch5-price-discovery-reconciliation.json',phbDmgPricePassageSupplement:'research/source-audit-batch5-phb-dmg-price-passage-records.json'};
const fullInputs=Object.fromEntries(Object.entries(paths).map(([k,p])=>[k,artifact(p)]));
const fullDocs=new Map(monetaryRowIdentityInputs.filter(c=>c.key!=='phbDmg').map(c=>[c.key,{...c,...artifact(c.path)}]));
const emptyData={canonical:{sourceInventories:[],siteClaims:[],sourcePageCensuses:[],fieldEvidenceBindings:[]},ua:{...fullDocs.get('ua').data,rowRecords:[],groupReviews:[]},passages:{records:[]},descriptions:{...fullDocs.get('descriptions').data,newSourceDescriptionRecords:[],pointerResolutionLinks:[]},receipts:{claimReceipts:[]},phbDmgCensus:{records:[]},uaCensus:{records:[]},monsterCensus:{claims:[]}};
const miniArtifact=(original,data)=>({...original,path:original.path+'#bounded-empty-copy',sha256:sha(JSON.stringify(data)),data});
const miniDocs=new Map([...fullDocs].map(([k,d])=>[k,miniArtifact(d,emptyData[k]??d.data)]));
emptyData.descriptions.inputSupplement={...emptyData.descriptions.inputSupplement,sha256:miniDocs.get('ua').sha256};miniDocs.set('descriptions',miniArtifact(fullDocs.get('descriptions'),emptyData.descriptions));
const miniInputs={...fullInputs,canonical:miniDocs.get('canonical'),equipment:miniArtifact(fullInputs.equipment,[]),equipmentBindings:miniArtifact(fullInputs.equipmentBindings,{bindings:[]}),uaSupplement:miniDocs.get('ua'),uaDescriptionSupplement:miniDocs.get('descriptions'),priceDiscoverySupplement:miniDocs.get('receipts'),phbDmgPricePassageSupplement:miniDocs.get('passages')};
const supportingInputByPath=new Map();for(const a of [...Object.values(fullInputs),...fullDocs.values(),candidate]){const prior=supportingInputByPath.get(a.path);if(prior&&prior!==a.sha256)throw Error('Supporting input changed between reads: '+a.path);supportingInputByPath.set(a.path,a.sha256);}
const supportingInputs=[...supportingInputByPath].sort(([a],[b])=>a.localeCompare(b)).map(([path,sha256])=>({path,sha256}));
const rowId='dmg-poison-ingestive-c';
const slim=data=>({...data,review:{...data.review,sourceRowsOrClaims:data.review.sourceRowsOrClaims.filter(r=>r.sourceRowOrClaimId===rowId)},additionalReferenceSheetReview:{...data.additionalReferenceSheetReview,rowComparisons:[]}});
const seed=candidate.data;
function run(data,{full=false}={}){
 const pd={path:candidate.path+'#bounded-declaration-matrix',sha256:sha(JSON.stringify(data)),data};
 const index=buildMonetarySourceIndex({...fullInputs,phbDmgSupplement:pd},{});
 const docs=new Map(fullDocs);docs.set('phbDmg',{...monetaryRowIdentityInputs.find(c=>c.key==='phbDmg'),...pd});
 const records=collectMonetaryRowIdentityRecords(docs).records;
 return {index,records};
}
const nominalFull=run(candidate.data,{full:true}),nominal=run(seed);
const findI=r=>r.index.sourceOccurrences.find(r=>r.sourceOccurrenceId==='phb-dmg:'+rowId);
const findR=r=>r.records.find(r=>r.uid==='phb-dmg-supplement-row:'+rowId);
const nominalClaimIds=findI(nominal).valueClaimIds;
const target=data=>{const row=data.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId===rowId),part=row.sourceContextParts[1],crop=data.review.evidenceCrops.find(c=>c.cropId===part.contextCropId);return {row,part,crop}};
const canonical=dpi=>`crop-local ${dpi}-dpi source-render pixels; left,top,right,bottom; half-open`;
const nodes=['part','part.focus','part.crop','part.sourceRender','crop','crop.sourceRender'];
const fields=['renderDpi','sourceRenderDpi','coordinateSpace','sourceCropFrame'];
const numberClasses=[['absent',undefined,'valid'],['agreeing-integer',300,'valid'],['conflicting-integer',150,'reject'],['zero',0,'reject'],['negative',-300,'reject'],['fraction',300.5,'reject'],['numeric-string','300','reject'],['null',null,'reject'],['boolean',true,'reject'],['empty-string','','reject'],['object',{dpi:300},'reject'],['array',[300],'reject']];
const spaceClasses=field=>[['absent',undefined,'valid'],['agreeing-dpi',field==='coordinateSpace'?canonical(300):'PyMuPDF CropBox-relative PageRect rendered at 300dpi','valid'],['conflicting-dpi',field==='coordinateSpace'?canonical(150):'PyMuPDF CropBox-relative PageRect rendered at 150dpi','reject'],['zero-dpi','crop-local 0-dpi source-render pixels','reject'],['negative-dpi','crop-local -300-dpi source-render pixels','reject'],['fractional-dpi','crop-local 300.5-dpi source-render pixels','reject'],['no-dpi-description',field==='coordinateSpace'?'pdf-page points':'PyMuPDF CropBox-relative PageRect',field==='coordinateSpace'?'reject':'valid'],['malformed-dpi','crop-local banana-dpi source-render pixels','reject'],['repeated-agreeing-dpi','300dpi; same frame rendered at 300dpi',field==='coordinateSpace'?'observe':'valid'],['multiple-conflicting-dpi','300dpi; contradictory frame rendered at 150dpi','reject'],['numeric-string','300',field==='coordinateSpace'?'reject':'valid'],['null',null,'reject'],['boolean',true,'reject'],['empty-string','','reject'],['object',{dpi:300},'reject'],['array',[300],'reject']];
function nodeObject(x,node,{absent=false}={}){
 if(node==='part')return x.part;if(node==='crop')return x.crop;
 const [owner,key]=node.split('.'),parent=x[owner];
 if(absent)return parent[key]&&typeof parent[key]==='object'?parent[key]:null;
 if(node==='part.sourceRender')return parent[key]={sourceRenderId:x.crop.sourceRender,sourceRenderSha256:x.crop.sourceRenderSha256,sourceRenderDimensionsPx:x.crop.sourceRenderDimensionsPx,renderDpi:300};
 if(node==='crop.sourceRender')return parent[key]={sourceRenderId:x.crop.sourceRender,sourceRenderSha256:x.crop.sourceRenderSha256,sourceRenderDimensionsPx:x.crop.sourceRenderDimensionsPx,renderDpi:300};
 return parent[key]={};
}
const cases=[];
for(const node of nodes)for(const field of fields)for(const [valueClass,value,policy]of field.endsWith('Dpi')?numberClasses:spaceClasses(field))cases.push({kind:'node-field-value',node,field,valueClass,value,expected:node==='crop.sourceRender'&&valueClass!=='absent'?'reject':policy});
for(const [valueClass,value,policy]of spaceClasses('coordinateSpace'))cases.push({kind:'same-crop-row-focus',node:'row.focus',field:'coordinateSpace',valueClass,value:valueClass==='agreeing-dpi'?canonical(150):valueClass==='conflicting-dpi'?canonical(300):valueClass==='repeated-agreeing-dpi'?'150dpi; same frame rendered at 150dpi':value,expected:valueClass==='absent'?'reject':policy});
const universePath='/tmp/pd-dpi-independent-review/frozen-352-case-universe.json';const universeBytes=readFileSync(universePath),universe=JSON.parse(universeBytes);
const identifiedCases=cases.map((c,i)=>({caseIndex:i,caseId:`decl-${String(i).padStart(3,'0')}`,...c}));
if(JSON.stringify(identifiedCases)!==JSON.stringify(universe.cases))throw Error('Case universe or expectations changed');
const chunkIndex=Number(process.env.REVIEW_CHUNK_INDEX),chunkCount=Number(process.env.REVIEW_CHUNK_COUNT);if(!Number.isInteger(chunkIndex)||!Number.isInteger(chunkCount)||chunkCount<1||chunkIndex<0||chunkIndex>=chunkCount)throw Error('Invalid chunk bounds');
const selectedCases=identifiedCases.filter(c=>c.caseIndex%chunkCount===chunkIndex);
const results=[];
for(const [i,c]of selectedCases.entries()){
 const data=structuredClone(seed),x=target(data);let object;
 if(c.kind==='same-crop-row-focus')object=x.row.focus;else object=nodeObject(x,c.node,{absent:c.valueClass==='absent'});
 if(object){if(c.valueClass==='absent')delete object[c.field];else object[c.field]=structuredClone(c.value);}
 try{
  const runResult=run(data),ir=findI(runResult),rr=findR(runResult),rowStatus=rr.contextEvidence.status;
  const rawAudit=auditMonetaryRowIdentity([rr]);rr.contextEvidence.status='declared-source-context-parts-linked';
  const forgedAudit=auditMonetaryRowIdentity([rr]);
  results.push({...c,indexStatus:ir.evidence.sourceContextPartsStatus,indexReason:ir.evidence.sourceContextPartsReason,rowStatus,rowAuditValid:rawAudit.validation.valid,rowAuditErrors:rawAudit.validation.structuralErrors,sameRecordForgedLinkedAuditValid:forgedAudit.validation.valid,sameRecordForgedErrors:forgedAudit.validation.structuralErrors,claimsRetained:JSON.stringify(ir.valueClaimIds)===JSON.stringify(nominalClaimIds),partsRetained:ir.evidence.sourceContextParts.length===2});
 }catch(error){results.push({...c,error:String(error)});}
 if((i+1)%50===0)console.log(`Captured ${i+1}/${selectedCases.length} declaration cases in chunk ${chunkIndex}`);
}
const nominalRows=nominalFull.records.filter(r=>Array.isArray(r.contextEvidence?.sourceContextParts)),nominalParts=nominalRows.flatMap(r=>r.contextEvidence.sourceContextParts),factFoci=nominalParts.filter(p=>Array.isArray(p.focusBoundsCropPixelsLTRB)).length,contextOnlyParts=nominalParts.filter(p=>!Array.isArray(p.focusBoundsCropPixelsLTRB)).length,supplementalCrops=nominalRows.reduce((n,r)=>n+(r.contextEvidence.supplementalContextCrops?.length??0),0);
if(nominalRows.length!==12||nominalParts.length!==28||factFoci!==25||contextOnlyParts!==3||supplementalCrops!==1)throw Error('Nominal ordered-part positive denominator changed or was filtered out');
const nominalAudit=auditMonetaryRowIdentity(nominalRows);
const report={schemaVersion:1,scope:'AFTER replay of the exact frozen352-case declaration universe; no source semantic, first90, or whole-book approval.',caseUniverse:{path:universePath,sha256:sha(universeBytes)},chunk:{index:chunkIndex,count:chunkCount,selectedCaseIndices:selectedCases.map(c=>c.caseIndex)},capturedCode:captureManifest,candidate:{path:candidate.path,sha256:candidate.sha256},supportingInputs,method:{nominalFullScope:{crops:candidate.data.review.evidenceCrops.length,orderedRows:nominalRows.length,orderedParts:nominalRows.reduce((n,r)=>n+r.contextEvidence.sourceContextParts.length,0),factFoci,contextOnlyParts,supplementalCrops,auditValid:nominalAudit.validation.valid},matrixExecution:'Every case executes the complete unchanged source-index and collector input scope, with only one declared leaf on the target row/crop mutated; all production denominator checks stay enabled.',nodes,fields,numericValueClasses:numberClasses.map(x=>x[0]),spaceValueClasses:spaceClasses('coordinateSpace').map(x=>x[0]),sameRecordForgedLinkedStatus:true},counts:{cases:results.length,expectedReject:results.filter(r=>r.expected==='reject').length,expectedValid:results.filter(r=>r.expected==='valid').length,observationOnly:results.filter(r=>r.expected==='observe').length,indexFalsePasses:results.filter(r=>r.expected==='reject'&&r.indexStatus==='declared-source-context-parts-linked').length,rowStatusFalsePasses:results.filter(r=>r.expected==='reject'&&r.rowStatus==='declared-source-context-parts-linked').length,rowAuditFalsePasses:results.filter(r=>r.expected==='reject'&&r.rowAuditValid).length,sameRecordForgedFalsePasses:results.filter(r=>r.expected==='reject'&&r.sameRecordForgedLinkedAuditValid).length,thrown:results.filter(r=>r.error).length},results};
report.supportingInputsStable=supportingInputs.every(f=>sha(readFileSync(f.path.startsWith('/')?f.path:repo+'/'+f.path))===f.sha256);if(!report.supportingInputsStable)throw Error('Supporting inputs changed during chunk');
report.capturedFilesStable=captureManifest.files.every(f=>sha(readFileSync(capture+'/'+f.path))===f.sha256);if(!report.capturedFilesStable)throw Error('Captured after files changed during chunk');
writeFileSync(capture+`/declaration-matrix-after-chunk-${chunkIndex}.json`,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report.counts));
