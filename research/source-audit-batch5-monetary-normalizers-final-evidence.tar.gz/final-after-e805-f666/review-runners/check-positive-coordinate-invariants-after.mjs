import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const capture=process.env.REVIEW_AFTER_CAPTURE,repo='/workspace/adnd1';
if(!capture)throw Error('REVIEW_AFTER_CAPTURE is required');
const sha=b=>createHash('sha256').update(b).digest('hex');
const captureManifest=JSON.parse(readFileSync(capture+'/capture-manifest.json'));
for(const f of captureManifest.files)if(sha(readFileSync(capture+'/'+f.path))!==f.sha256)throw Error('Captured dependency changed: '+f.path);
const artifact=p=>{const b=readFileSync(p.startsWith('/')?p:repo+'/'+p);return {path:p,sha256:sha(b),data:JSON.parse(b)}};
const {buildMonetarySourceIndex}=await import(pathToFileURL(capture+'/tools/monetary-source-inventory.mjs'));
const {collectMonetaryRowIdentityRecords,auditMonetaryRowIdentity,monetaryRowIdentityInputs}=await import(pathToFileURL(capture+'/tools/monetary-row-identity-audit.mjs'));
const candidate=artifact('/tmp/batch5-phbdmg-money-corrections-v5/proposal-v5/phb-dmg-additional-prices-correction-candidate-v5.json');
if(candidate.sha256!=='e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6')throw Error('candidate changed');
const paths={canonical:'research/price-source-inventory.json',equipment:'equipment.json',equipmentBindings:'research/equipment-source-row-bindings.json',uaSupplement:'research/source-audit-batch5-ua-additional-prices.json',uaDescriptionSupplement:'research/source-audit-batch5-price-description-records.json',priceDiscoverySupplement:'research/source-audit-batch5-price-discovery-reconciliation.json',phbDmgPricePassageSupplement:'research/source-audit-batch5-phb-dmg-price-passage-records.json'};
const fullInputs=Object.fromEntries(Object.entries(paths).map(([k,p])=>[k,artifact(p)]));
const fullDocs=new Map(monetaryRowIdentityInputs.filter(c=>c.key!=='phbDmg').map(c=>[c.key,{...c,...artifact(c.path)}]));
const emptyData={canonical:{sourceInventories:[],siteClaims:[],sourcePageCensuses:[],fieldEvidenceBindings:[]},ua:{...fullDocs.get('ua').data,rowRecords:[],groupReviews:[]},passages:{records:[]},descriptions:{...fullDocs.get('descriptions').data,newSourceDescriptionRecords:[],pointerResolutionLinks:[]},receipts:{claimReceipts:[]},phbDmgCensus:{records:[]},uaCensus:{records:[]},monsterCensus:{claims:[]}};
const miniArtifact=(original,data)=>({...original,path:original.path+'#bounded-empty-copy',sha256:sha(JSON.stringify(data)),data});
const miniDocs=new Map([...fullDocs].map(([k,d])=>[k,miniArtifact(d,emptyData[k]??d.data)]));
emptyData.descriptions.inputSupplement={...emptyData.descriptions.inputSupplement,sha256:miniDocs.get('ua').sha256};miniDocs.set('descriptions',miniArtifact(fullDocs.get('descriptions'),emptyData.descriptions));
const miniInputs={...fullInputs,canonical:miniDocs.get('canonical'),equipment:miniArtifact(fullInputs.equipment,[]),equipmentBindings:miniArtifact(fullInputs.equipmentBindings,{bindings:[]}),uaSupplement:miniDocs.get('ua'),uaDescriptionSupplement:miniDocs.get('descriptions'),priceDiscoverySupplement:miniDocs.get('receipts'),phbDmgPricePassageSupplement:miniDocs.get('passages')};
const supportingInputByPath=new Map();for(const a of [...Object.values(fullInputs),...fullDocs.values(),candidate]){const prior=supportingInputByPath.get(a.path);if(prior&&prior!==a.sha256)throw Error('Supporting input changed between reads: '+a.path);supportingInputByPath.set(a.path,a.sha256);}
const supportingInputs=[...supportingInputByPath].sort(([a],[b])=>a.localeCompare(b)).map(([path,sha256])=>({path,sha256}));
const rowId='dmg-poison-ingestive-c';
const slim=data=>({...data,review:{...data.review,sourceRowsOrClaims:data.review.sourceRowsOrClaims.filter(r=>r.sourceRowOrClaimId===rowId)},additionalReferenceSheetReview:{...data.additionalReferenceSheetReview,rowComparisons:[]}});
const seed=candidate.data;
function run(data,{full=false}={}){
 const pd={path:candidate.path+'#bounded-declaration-matrix',sha256:sha(JSON.stringify(data)),data};
 const index=buildMonetarySourceIndex({...fullInputs,phbDmgSupplement:pd},{});
 const docs=new Map(fullDocs);docs.set('phbDmg',{...monetaryRowIdentityInputs.find(c=>c.key==='phbDmg'),...pd});
 const records=collectMonetaryRowIdentityRecords(docs).records;
 return {index,records};
}

const output=run(candidate.data,{full:true});
const crops=new Map(candidate.data.review.evidenceCrops.map(c=>[c.cropId,c]));
const registry=JSON.parse(readFileSync(capture+'/research/monetary-source-render-frames.json'));
const orderedRows=candidate.data.review.sourceRowsOrClaims.filter(r=>Array.isArray(r.sourceContextParts));
const pageSpace='original source-render page pixels; top-left origin; [left,top,right,bottom] half-open';
const cropSpace='source-page-global source-render pixels; top-left origin; [left,top,right,bottom] half-open';
const localSpace=dpi=>`crop-local ${dpi}-dpi source-render pixels; left,top,right,bottom; half-open`;
const stable=v=>Array.isArray(v)?`[${v.map(stable).join(',')}]`:v&&typeof v==='object'?`{${Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')}}`:JSON.stringify(v);
const eq=(a,b)=>stable(a??null)===stable(b??null);
const errors=[],parts=[],supplementals=[];
const expectedSource=s=>({book:s.bookKey??s.book,printedPage:s.printedPage??s.page,pdfPage:s.pdfPage,sourcePdfSha256:s.sourceFileSha256??s.sourcePdfSha256??s.sourceSha256});
const sourceProjection=s=>({book:s.book,printedPage:s.printedPage,pdfPage:s.pdfPage,sourcePdfSha256:s.sourcePdfSha256});
function checkFrame({side,rowId,partId,source,render,metadata,rawSource,crop}){
 const prefix=`${side}:${rowId}:${partId}`;
 if(!eq(sourceProjection(source),expectedSource(rawSource)))errors.push(prefix+' source tuple changed');
 const frame=registry.frames.find(f=>f.book===source.book&&f.printedPage===source.printedPage&&f.pdfPage===source.pdfPage&&f.sourcePdfSha256===source.sourcePdfSha256&&f.sourceRenderSha256===crop.sourceRenderSha256&&eq(f.sourceRenderDimensionsPx,crop.sourceRenderDimensionsPx));
 if(!frame)errors.push(prefix+' not matched to exact registered frame');
 if(render?.sourceRenderId!==crop.sourceRender||render?.sourceRenderSha256!==crop.sourceRenderSha256||!eq(render?.sourceRenderDimensionsPx,crop.sourceRenderDimensionsPx)||render?.renderDpi!==frame?.renderDpi)errors.push(prefix+' source render numeric/hash identity changed');
 const pairs={sourcePdfSha256:source.sourcePdfSha256,sourceRenderSha256:crop.sourceRenderSha256,sourceRenderDimensionsPx:crop.sourceRenderDimensionsPx,cropBoundsPixelsLTRB:crop.cropBoundsPixelsLTRB,cropDimensionsPx:crop.cropDimensionsPx,cropSha256:crop.cropSha256,renderDpi:frame?.renderDpi};
 for(const [key,value]of Object.entries(pairs))if(!eq(metadata?.[key],value))errors.push(prefix+' '+key+' changed');
 if(render?.coordinateSpace!==pageSpace||metadata?.coordinateSpace!==cropSpace||metadata?.cropBoundsPixelsCoordinateSpace!==cropSpace)errors.push(prefix+' page/global coordinate labels incorrect');
 return frame;
}
for(const raw of orderedRows){
 const indexRow=output.index.sourceOccurrences.find(r=>r.sourceOccurrenceId==='phb-dmg:'+raw.sourceRowOrClaimId),auditRow=output.records.find(r=>r.uid==='phb-dmg-supplement-row:'+raw.sourceRowOrClaimId);
 if(indexRow?.evidence.sourceContextPartsStatus!=='declared-source-context-parts-linked'||auditRow?.contextEvidence.status!=='declared-source-context-parts-linked')errors.push(raw.sourceRowOrClaimId+' nominal context is not linked');
 if(auditRow?.contextEvidence.fingerprintVersion!=='ordered-source-context-parts-v2')errors.push(raw.sourceRowOrClaimId+' does not use explicit focus-space fingerprint v2');
 const projections={};
 for(const [side,ps,ss]of [['index',indexRow.evidence.sourceContextParts,indexRow.evidence.supplementalContextCrops],['rowtool',auditRow.contextEvidence.sourceContextParts,auditRow.contextEvidence.supplementalContextCrops]]){
  if(ps.length!==raw.sourceContextParts.length)errors.push(side+':'+raw.sourceRowOrClaimId+' part count changed');
  projections[side]=[];
  for(const [i,p]of ps.entries()){
   const rp=raw.sourceContextParts[i],crop=crops.get(rp.contextCropId),prefix=side+':'+raw.sourceRowOrClaimId+':'+p.partId;
   if(p.partId!==rp.partId||p.order!==rp.order||p.role!==rp.role||p.cropId!==rp.contextCropId||!eq(p.factPointers,rp.factPointers))errors.push(prefix+' part identity/order changed');
   const frame=checkFrame({side,rowId:raw.sourceRowOrClaimId,partId:p.partId,source:p.source,render:p.sourceRender,metadata:p.crop,rawSource:rp.source,crop});
   const expectedFocus=rp.focusBoundsCropPixelsLTRB??rp.focus?.focusBoundsCropPixelsLTRB??((rp.contextCropId===raw.focus?.contextCropId||rp.contextCropId===raw.contextCropId)?raw.focus?.focusBoundsCropPixelsLTRB:null)??null;
   if(!eq(p.focusBoundsCropPixelsLTRB,expectedFocus))errors.push(prefix+' crop-local focus numbers changed');
   if(p.focusCoordinateSpace!==(expectedFocus?localSpace(frame?.renderDpi):null))errors.push(prefix+' crop-local focus label incorrect');
   const expectedPdf=rp.cropBoundsPdfPagePointsTopLeftLTRB??rp.crop?.cropBoundsPdfPagePointsTopLeftLTRB??crop.cropBoundsPdfPagePointsTopLeftLTRB??crop.cropBoundsPdfPagePointsTopLeft??null;
   if(!eq(p.crop.cropBoundsPdfPagePointsTopLeftLTRB,expectedPdf)||!eq(p.sourceRender.pageBoundsPdfPagePointsTopLeftLTRB,crop.pageBoundsPdfPagePointsTopLeftLTRB??null))errors.push(prefix+' PDF/page bounds changed');
   const projection={rowId:raw.sourceRowOrClaimId,partId:p.partId,order:p.order,role:p.role,source:sourceProjection(p.source),sourceRenderSha256:p.sourceRender.sourceRenderSha256,sourceRenderDimensionsPx:p.sourceRender.sourceRenderDimensionsPx,renderDpi:p.sourceRender.renderDpi,cropBoundsPixelsLTRB:p.crop.cropBoundsPixelsLTRB,cropDimensionsPx:p.crop.cropDimensionsPx,cropSha256:p.crop.cropSha256,cropBoundsPdfPagePointsTopLeftLTRB:p.crop.cropBoundsPdfPagePointsTopLeftLTRB??null,focusBoundsCropPixelsLTRB:p.focusBoundsCropPixelsLTRB??null};
   projections[side].push(projection);parts.push({side,...projection,sourceRenderCoordinateSpace:p.sourceRender.coordinateSpace,cropCoordinateSpace:p.crop.coordinateSpace,focusCoordinateSpace:p.focusCoordinateSpace});
  }
  const expectedSupplemental=[...new Set([raw.contextCropId,raw.focus?.contextCropId].filter(id=>id&&!raw.sourceContextParts.some(p=>p.contextCropId===id)))];
  if(!eq(ss.map(c=>c.cropId),expectedSupplemental))errors.push(side+':'+raw.sourceRowOrClaimId+' supplemental identity changed');
  for(const c of ss){const crop=crops.get(c.cropId);checkFrame({side,rowId:raw.sourceRowOrClaimId,partId:c.cropId,source:c.source,render:c.sourceRender,metadata:c.metadata,rawSource:raw.source,crop});supplementals.push({side,rowId:raw.sourceRowOrClaimId,cropId:c.cropId,source:sourceProjection(c.source),sourceRenderSha256:c.sourceRender.sourceRenderSha256,sourceRenderDimensionsPx:c.sourceRender.sourceRenderDimensionsPx,renderDpi:c.sourceRender.renderDpi,cropBoundsPixelsLTRB:c.metadata.cropBoundsPixelsLTRB,cropDimensionsPx:c.metadata.cropDimensionsPx,cropSha256:c.metadata.cropSha256,sourceRenderCoordinateSpace:c.sourceRender.coordinateSpace,cropCoordinateSpace:c.metadata.coordinateSpace});}
 }
 if(!eq(projections.index,projections.rowtool))errors.push(raw.sourceRowOrClaimId+' index and rowtool numeric/source projections differ');
}
const rows=output.records.filter(r=>Array.isArray(r.contextEvidence?.sourceContextParts)),audit=auditMonetaryRowIdentity(rows);
const counts={rows:rows.length,indexParts:parts.filter(p=>p.side==='index').length,rowParts:parts.filter(p=>p.side==='rowtool').length,indexDpi150:parts.filter(p=>p.side==='index'&&p.renderDpi===150).length,indexDpi300:parts.filter(p=>p.side==='index'&&p.renderDpi===300).length,rowDpi150:parts.filter(p=>p.side==='rowtool'&&p.renderDpi===150).length,rowDpi300:parts.filter(p=>p.side==='rowtool'&&p.renderDpi===300).length,factFociPerSide:parts.filter(p=>p.side==='index'&&p.focusBoundsCropPixelsLTRB!==null).length,contextOnlyPerSide:parts.filter(p=>p.side==='index'&&p.focusBoundsCropPixelsLTRB===null).length,supplementalPerSide:supplementals.filter(p=>p.side==='index').length};
if(counts.rows!==12||counts.indexParts!==28||counts.rowParts!==28||counts.indexDpi150!==24||counts.indexDpi300!==4||counts.rowDpi150!==24||counts.rowDpi300!==4||counts.factFociPerSide!==25||counts.contextOnlyPerSide!==3||counts.supplementalPerSide!==1)errors.push('nonvacuous positive denominator changed');
if(!audit.validation.valid)errors.push(...audit.validation.structuralErrors);
const supportingInputsStable=supportingInputs.every(f=>sha(readFileSync(f.path.startsWith('/')?f.path:repo+'/'+f.path))===f.sha256);
const codeStable=captureManifest.files.every(f=>sha(readFileSync(capture+'/'+f.path))===f.sha256);if(!supportingInputsStable||!codeStable)errors.push('supporting inputs or captured code changed');
const report={schemaVersion:1,scope:'Existing positive28-part and one-supplemental declaration/coordinate-label checks; exact numeric source/crop/focus projection compared with frozen candidate. No source semantics or first90 approval.',capturedCode:captureManifest,candidate:{path:candidate.path,sha256:candidate.sha256},supportingInputs,supportingInputsStable,codeStable,counts,validation:{valid:errors.length===0,errors},parts,supplementals};
writeFileSync(capture+'/positive-coordinate-numeric-invariants-after.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({counts,validation:report.validation},null,2));
