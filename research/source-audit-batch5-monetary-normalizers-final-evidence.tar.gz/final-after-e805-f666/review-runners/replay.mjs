import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const repo='/workspace/adnd1';
const candidatePath='/tmp/batch5-phbdmg-money-corrections-v5/proposal-v5/phb-dmg-additional-prices-correction-candidate-v5.json';
const digest=b=>createHash('sha256').update(b).digest('hex');
const artifact=path=>{const bytes=readFileSync(path.startsWith('/')?path:repo+'/'+path);return {path,sha256:digest(bytes),data:JSON.parse(bytes)}};
const codeNames=new Set(['monetary-source-inventory.mjs','monetary-row-identity-audit.mjs']);
for(const n of codeNames){const code=readFileSync(repo+'/tools/'+n,'utf8');for(const m of code.matchAll(/from ['"]\.\/([^'"]+)['"]/g))if(existsSync(repo+'/tools/'+m[1]))codeNames.add(m[1]);}
const codeAtLoad=Object.fromEntries([...codeNames].map(n=>[n,digest(readFileSync(repo+'/tools/'+n))]));
const registryPath='research/monetary-source-render-frames.json';const registryAtLoad=existsSync(repo+'/'+registryPath)?artifact(registryPath):null;
const indexTool=await import(pathToFileURL(repo+'/tools/monetary-source-inventory.mjs'));
const rowTool=await import(pathToFileURL(repo+'/tools/monetary-row-identity-audit.mjs'));
const candidate=artifact(candidatePath);
if(candidate.sha256!=='e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6')throw Error('candidate changed');
const inputPaths={canonical:'research/price-source-inventory.json',equipment:'equipment.json',equipmentBindings:'research/equipment-source-row-bindings.json',uaSupplement:'research/source-audit-batch5-ua-additional-prices.json',uaDescriptionSupplement:'research/source-audit-batch5-price-description-records.json',priceDiscoverySupplement:'research/source-audit-batch5-price-discovery-reconciliation.json',phbDmgPricePassageSupplement:'research/source-audit-batch5-phb-dmg-price-passage-records.json'};
const inputs=Object.fromEntries(Object.entries(inputPaths).map(([key,path])=>[key,artifact(path)]));
const documentBase=new Map(rowTool.monetaryRowIdentityInputs.filter(d=>d.key!=='phbDmg').map(d=>[d.key,{...d,...artifact(d.path)}]));
function run(data){
 const bytes=Buffer.from(JSON.stringify(data));
 const pd={path:candidatePath+'#independent-private-review',sha256:digest(bytes),data};
 const index=indexTool.buildMonetarySourceIndex({...inputs,phbDmgSupplement:pd});
 const docs=new Map(documentBase);docs.set('phbDmg',{...rowTool.monetaryRowIdentityInputs.find(d=>d.key==='phbDmg'),...pd});
 const records=rowTool.collectMonetaryRowIdentityRecords(docs).records.filter(r=>r.surface==='phb-dmg-supplement-row');
 return {index,records};
}
const recordPart=p=>({partId:p.partId,cropId:p.cropId,source:p.source,renderDpi:p.sourceRender?.renderDpi,cropDpi:p.crop?.renderDpi,coordinateSpace:p.sourceRender?.coordinateSpace,sourceRenderSha256:p.sourceRender?.sourceRenderSha256,sourceRenderDimensionsPx:p.sourceRender?.sourceRenderDimensionsPx,declaredSourceRenderDpi:p.declaredFrame?.linkedCrop?.sourceRenderDpi??p.sourceRender?.declaredDpi?.cropSourceRenderDpi??null,declaredSourceCropFrame:p.declaredFrame?.linkedCrop?.sourceCropFrame??p.sourceRender?.declaredCoordinateSpaces?.cropSourceCropFrame??null});
const base=run(candidate.data);
const orderedRows=candidate.data.review.sourceRowsOrClaims.filter(r=>Object.hasOwn(r,'sourceContextParts'));
const rows=orderedRows.map(r=>{const occurrence=base.index.sourceOccurrences.find(o=>o.sourceOccurrenceId==='phb-dmg:'+r.sourceRowOrClaimId),record=base.records.find(o=>o.id===r.sourceRowOrClaimId);return {rowId:r.sourceRowOrClaimId,indexStatus:occurrence.evidence.sourceContextPartsStatus,indexReason:occurrence.evidence.sourceContextPartsReason,indexParts:occurrence.evidence.sourceContextParts.map(recordPart),rowtoolStatus:record.contextEvidence.status,rowtoolParts:record.contextEvidence.sourceContextParts.map(recordPart)};});
const basePartRecords=base.records.filter(r=>Array.isArray(r.contextEvidence?.sourceContextParts));const baseParts=basePartRecords.flatMap(r=>r.contextEvidence.sourceContextParts);if(basePartRecords.length!==12||baseParts.length!==28||baseParts.filter(p=>Array.isArray(p.focusBoundsCropPixelsLTRB)).length!==25||basePartRecords.reduce((n,r)=>n+(r.contextEvidence.supplementalContextCrops?.length??0),0)!==1)throw Error('Nonvacuous nominal positive changed');
const baseAudit=rowTool.auditMonetaryRowIdentity(basePartRecords);
const report={registry:registryAtLoad?{path:registryPath,sha256:registryAtLoad.sha256,counts:registryAtLoad.data.counts,scope:'Frame declaration authority; independent actual-pixel review is owned by interim parent d9d3f1ac receipt.'}:null,rowtoolNominalAudit:{records:basePartRecords.length,parts:baseParts.length,valid:baseAudit.validation.valid,errors:baseAudit.validation.structuralErrors},scope:'Independent structural declaration/DPI review only; no source semantics or first90 approval.',candidate:{path:candidate.path,sha256:candidate.sha256},code:codeAtLoad,denominators:{crops:candidate.data.review.evidenceCrops.length,orderedRows:orderedRows.length,orderedParts:orderedRows.reduce((n,r)=>n+r.sourceContextParts.length,0)},rows};
if(process.env.PD_DPI_MUTATIONS==='1'){
 const noteRowId='dmg-poison-ingestive-c';
 const nominalClaimIds=base.index.sourceOccurrences.find(o=>o.sourceOccurrenceId==='phb-dmg:'+noteRowId).valueClaimIds;
 const target=data=>{const row=data.review.sourceRowsOrClaims.find(r=>r.sourceRowOrClaimId===noteRowId);return {row,part:row.sourceContextParts[1],crop:data.review.evidenceCrops.find(c=>c.cropId===row.sourceContextParts[1].contextCropId)}};
 const cases=[
 ['part source absent',x=>{delete x.part.source}],
 ['part source empty',x=>{x.part.source={}}],
 ['part source missing book',x=>{delete x.part.source.book;delete x.part.source.bookKey}],
 ['part source missing PDF hash',x=>{delete x.part.source.sourceFileSha256}],
 ['part source missing printed page',x=>{delete x.part.source.printedPage}],
 ['part source missing PDF page',x=>{delete x.part.source.pdfPage}],
 ['part source conflicting book aliases',x=>{x.part.source.book='PHB'}],
 ['part source conflicting hash aliases',x=>{x.part.source.sourcePdfSha256='f'.repeat(64)}],
 ['part source conflicting printed page aliases',x=>{x.part.source.page=20}],
 ['part source null PDF page',x=>{x.part.source.pdfPage=null}],
 ['part source null hash alias alongside valid hash',x=>{x.part.source.sourcePdfSha256=null}],
 ['part source null printed page alias alongside valid page',x=>{x.part.source.page=null}],
 ['part source empty book alias alongside valid book',x=>{x.part.source.book=''}],
 ['crop source mismatched PDF page',x=>{x.crop.pdfPage=21}],
 ['crop source mismatched printed page',x=>{x.crop.printedPage=20}],
 ['crop source mismatched book',x=>{x.crop.book='PHB'}],
 ['crop source conflicting hash aliases',x=>{x.crop.sourceFileSha256='f'.repeat(64)}],
 ['crop nested source conflicting page',x=>{x.crop.source={...x.part.source,pdfPage:21}}],
 ['crop renderDpi conflicts with sourceRenderDpi',x=>{x.crop.renderDpi=150}],
 ['crop sourceRenderDpi zero',x=>{x.crop.sourceRenderDpi=0}],
 ['crop sourceRenderDpi string',x=>{x.crop.sourceRenderDpi='300'}],
 ['crop sourceRenderDpi null',x=>{x.crop.sourceRenderDpi=null}],
 ['crop own DPI/frame missing must not borrow row',x=>{delete x.crop.sourceRenderDpi;delete x.crop.sourceCropFrame}],
 ['unknown secondary frame without own DPI must not borrow row',x=>{delete x.crop.sourceRenderDpi;delete x.crop.sourceCropFrame;x.crop.sourceRenderSha256='e'.repeat(64)}],
 ['known render hash wrong dimensions without own DPI',x=>{delete x.crop.sourceRenderDpi;delete x.crop.sourceCropFrame;x.crop.sourceRenderDimensionsPx=[2441,3194]}],
 ['known render hash wrong source page without own DPI',x=>{delete x.crop.sourceRenderDpi;delete x.crop.sourceCropFrame;x.part.source.printedPage=22;x.part.source.pdfPage=23;x.crop.printedPage=22;x.crop.pdfPage=23}],
 ['part coordinate DPI conflicts',x=>{x.part.coordinateSpace='crop-local 150-dpi source-render pixels'}],
 ['part focus coordinate DPI conflicts',x=>{x.part.focus={coordinateSpace:'crop-local 150-dpi source-render pixels'}}],
 ['part crop renderDpi conflicts',x=>{x.part.crop={renderDpi:150}}],
 ['part crop sourceRenderDpi conflicts',x=>{x.part.crop={sourceRenderDpi:150}}],
 ['part sourceRender renderDpi conflicts',x=>{x.part.sourceRender={sourceRenderId:x.crop.sourceRender,sourceRenderSha256:x.crop.sourceRenderSha256,sourceRenderDimensionsPx:x.crop.sourceRenderDimensionsPx,renderDpi:150}}],
 ['crop coordinate DPI conflicts',x=>{x.crop.coordinateSpace='crop-local 150-dpi source-render pixels'}],
 ['crop source frame DPI conflicts',x=>{x.crop.sourceCropFrame='PyMuPDF CropBox-relative PageRect rendered at 150dpi'}],
 ['primary row focus DPI conflicts with its own registered crop',x=>{x.row.focus.coordinateSpace='crop-local 300-dpi source-render pixels; left,top,right,bottom; half-open'}],
 ['primary row focus declares incompatible units without DPI',x=>{x.row.focus.coordinateSpace='pdf-page points';}],
 ['primary row focus has malformed DPI text',x=>{x.row.focus.coordinateSpace='crop-local banana-dpi source-render pixels';}],
 ['single source frame string has contradictory DPI values',x=>{x.crop.sourceCropFrame='PyMuPDF CropBox-relative PageRect rendered at 300dpi; other explicit frame declaration 150dpi';}],
 ['declared coordinate space has malformed DPI text',x=>{x.part.coordinateSpace='crop-local banana-dpi source-render pixels';}],
 ['declared coordinate space uses incompatible units without DPI',x=>{x.part.coordinateSpace='pdf-page points';}],
 ];
 report.rawMutationCases=cases.filter(([name])=>!process.env.PD_DPI_CASES||process.env.PD_DPI_CASES.split('|').includes(name)).map(([name,mutate])=>{const data=structuredClone(candidate.data);mutate(target(data));try{const result=run(data),occurrence=result.index.sourceOccurrences.find(o=>o.sourceOccurrenceId==='phb-dmg:'+noteRowId),record=result.records.find(r=>r.id===noteRowId);const rawRowtoolStatus=record.contextEvidence.status;const forged=structuredClone(record);forged.contextEvidence.status='declared-source-context-parts-linked';const forgedAudit=rowTool.auditMonetaryRowIdentity([forged]);record.contextEvidence.status='declared-source-context-parts-linked';const sameRecordForgedAudit=rowTool.auditMonetaryRowIdentity([record]);return {name,indexValueClaimIdsUnchanged:JSON.stringify(occurrence.valueClaimIds)===JSON.stringify(nominalClaimIds),indexPartsRetained:occurrence.evidence.sourceContextParts.length===2,indexStatus:occurrence.evidence.sourceContextPartsStatus,indexReason:occurrence.evidence.sourceContextPartsReason,indexNote:recordPart(occurrence.evidence.sourceContextParts[1]),rowtoolStatus:rawRowtoolStatus,rowtoolNote:recordPart(record.contextEvidence.sourceContextParts[1]),forgedSameRecordLinkedStatusAuditValid:sameRecordForgedAudit.validation.valid,forgedSameRecordLinkedStatusAuditErrors:sameRecordForgedAudit.validation.structuralErrors,forgedLinkedStatusAuditValid:forgedAudit.validation.valid,forgedLinkedStatusAuditErrors:forgedAudit.validation.structuralErrors};}catch(e){return {name,threw:String(e)}}});
 const registryLabelData=structuredClone(candidate.data);const registryLabelTarget=target(registryLabelData);registryLabelTarget.crop.sourceRender='cosmetic-label-150.png';registryLabelTarget.crop.label='cosmetic source label';const registryLabelResult=run(registryLabelData);const registryLabelOccurrence=registryLabelResult.index.sourceOccurrences.find(o=>o.sourceOccurrenceId==='phb-dmg:'+noteRowId),registryLabelRecord=registryLabelResult.records.find(r=>r.id===noteRowId);report.registryLabelPositive={indexStatus:registryLabelOccurrence.evidence.sourceContextPartsStatus,indexNote:recordPart(registryLabelOccurrence.evidence.sourceContextParts[1]),rowtoolStatus:registryLabelRecord.contextEvidence.status,rowtoolNote:recordPart(registryLabelRecord.contextEvidence.sourceContextParts[1]),auditValid:rowTool.auditMonetaryRowIdentity([registryLabelRecord]).validation.valid};
 const normalizedCases=[
 ['rewrite both normalized note DPI to150',r=>{const p=r.contextEvidence.sourceContextParts[1];p.sourceRender.renderDpi=150;p.crop.renderDpi=150;p.sourceRender.coordinateSpace='crop-local 150-dpi source-render pixels; left,top,right,bottom; half-open';p.crop.coordinateSpace=p.sourceRender.coordinateSpace;}],
 ['rewrite normalized note source page toprimary',r=>{const p=r.contextEvidence.sourceContextParts[1];p.source.printedPage=20;p.source.pdfPage=21;}],
 ['rewrite note normalized render identity',r=>{const p=r.contextEvidence.sourceContextParts[1];p.sourceRender.sourceRenderSha256='d'.repeat(64);p.crop.sourceRenderSha256='d'.repeat(64);}],
 ['rewrite normalized declared DPI alias',r=>{r.contextEvidence.sourceContextParts[1].sourceRender.declaredDpi.cropSourceRenderDpi=150;}],
 ['rewrite normalized declared frame text alias',r=>{r.contextEvidence.sourceContextParts[1].sourceRender.declaredCoordinateSpaces.cropSourceCropFrame='PyMuPDF CropBox-relative PageRect rendered at 150dpi';}],
 ['rewrite normalized declared source page alias',r=>{r.contextEvidence.sourceContextParts[1].crop.declaredSourceFrame.cropTopLevel.pdfPage=21;}]
 ];
 report.normalizedForgeryCases=normalizedCases.map(([name,mutate])=>{const r=run(structuredClone(candidate.data)).records.find(r=>r.id===noteRowId);mutate(r);r.contextEvidence.status='declared-source-context-parts-linked';const a=rowTool.auditMonetaryRowIdentity([r]);return {name,valid:a.validation.valid,errors:a.validation.structuralErrors};});

}
const output=process.argv[2]||'/tmp/pd-dpi-independent-review/before.json';
report.codeAtCompletion=Object.fromEntries(Object.keys(codeAtLoad).map(n=>[n,digest(readFileSync(repo+'/tools/'+n))]));report.registryStable=!registryAtLoad||digest(readFileSync(repo+'/'+registryPath))===registryAtLoad.sha256;report.codeStable=JSON.stringify(report.code)===JSON.stringify(report.codeAtCompletion)&&report.registryStable;
if(!report.codeStable)throw Error('code changed during replay; no stable approval report written');
writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output,code:report.code,denominators:report.denominators,noteParts:rows.flatMap(r=>r.indexParts.filter(p=>p.cropId==='crop-dmg-poison-dose-and-manufacture-04').map(p=>({rowId:r.rowId,...p}))),indexStatuses:[...new Set(rows.map(r=>r.indexStatus))],rowtoolStatuses:[...new Set(rows.map(r=>r.rowtoolStatus))]},null,2));
