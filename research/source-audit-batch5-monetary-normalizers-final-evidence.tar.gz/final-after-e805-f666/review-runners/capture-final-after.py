from pathlib import Path
import hashlib,json,re
repo=Path('/workspace/adnd1'); base=Path('/tmp/pd-dpi-independent-review'); out=base/'final-after-e805-f666'
if out.exists(): raise SystemExit('After capture already exists')
expected={
 'tools/monetary-source-inventory.mjs':'e805a03e6dd0828d6f066e68b9070b0e2df1065b3a83028d0c8038f467423ba2',
 'tools/monetary-row-identity-audit.mjs':'f666dd837a1a08ffd7ca926766f85b8af4b60e24724a8b2c7b60a1a61943dfa8',
 'tools/monetary-source-render-frames.mjs':'44dc5c4d5233fdf2a8b1a36742712f1b36f69ebcc8d2b6d8208303cdb9b41a39',
 'research/monetary-source-render-frames.json':'29e0ee3ae3cdaf304b67ca99fe7c51a391e7a1b44b63f12aa9258ce02fed3af7',
 'research/source-audit-batch5-pd179-v5-fresh-frame-replay-independent-review.json':'931ecd38e8dc2660e200e1d4fb5a8f8e3721801e5d4f67020aaee329da8e9106',
 'research/source-audit-batch5-pd179-v5-crop-frame-bindings-independent-review.json':'e04274a0aa8e04ee0a09962c24ed2290c6e3e5e5d92ef79aad38caf625147eee',
 'tests/monetary-source-inventory.test.mjs':'feb76188508eccf4243b431dd82360ecc2036755e3bd09feba31ffb727c5eaa7',
 'tests/monetary-row-identity-audit.test.mjs':'0541d125b7ff09389399106a11e66fcdf719c672fa127375a8858fc8ae54a81c',
 'tests/ua-context-migration-bridge.test.mjs':'63d1179d29dd2dea503ad170c2cc84dd9598b843b76088580324b7006eb00fcd'
}
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=set(expected); queue=[p for p in paths if p.startswith('tools/')]
while queue:
 p=queue.pop(); text=(repo/p).read_text()
 for match in re.finditer(r"from\s+['\"](\.[^'\"]+)['\"]",text):
  dep=str((Path(p).parent/match.group(1)))
  if dep not in paths:paths.add(dep);queue.append(dep)
paths.add('tests/monetary-context-adapter-protocol.test.mjs')
files=[]
for p in sorted(paths):
 b=(repo/p).read_bytes(); h=sha(b)
 if p in expected and h!=expected[p]:raise SystemExit(f'Hash changed: {p} {h}')
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 files.append({'path':p,'sha256':h,'bytes':len(b)})
row=(repo/'tools/monetary-row-identity-audit.mjs').read_text()
inputblock=row.split('export const monetaryRowIdentityInputs=[',1)[1].split('].map(',1)[0]
inputs={m.group(1) for m in re.finditer(r"\['[^']+','([^']+)'\]",inputblock)}
inputs.update(['equipment.json','research/equipment-source-row-bindings.json'])
# Preserve runtime archive dependencies as bytes; matrix uses direct APIs without global loader.
inputs.update(['tests/fixtures/monetary-source-ua-583-before.json.gz','tests/fixtures/monetary-source-phbdmg-179-before.json.gz'])
support=[]
for p in sorted(inputs):
 b=(repo/p).read_bytes();dest=out/'supporting-inputs'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 support.append({'path':p,'sourceSnapshotPath':'supporting-inputs/'+p,'sha256':sha(b),'bytes':len(b)})
p=Path('/tmp/batch5-phbdmg-money-corrections-v5/proposal-v5/phb-dmg-additional-prices-correction-candidate-v5.json');b=p.read_bytes()
if sha(b)!='e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6':raise SystemExit('candidate hash changed')
dest=out/'supporting-inputs/private-candidate-e4cf.json';dest.write_bytes(b);support.append({'path':str(p),'sourceSnapshotPath':str(dest.relative_to(out)),'sha256':sha(b),'bytes':len(b)})
# Capture the exact authorized transport and assertions alongside implementation.
for p in ['replay-frozen-matrix-after.mjs','merge-frozen-matrix-after.mjs','check-positive-coordinate-invariants-after.mjs','replay.mjs','frozen-352-case-universe.json']:
 b=(base/p).read_bytes();dest=out/'review-runners'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);files.append({'path':str(dest.relative_to(out)),'sha256':sha(b),'bytes':len(b)})
for f in files:
 if f['path'].startswith('review-runners/'):continue
 if sha((repo/f['path']).read_bytes())!=f['sha256']:raise SystemExit('Live source changed during capture: '+f['path'])
for f in support:
 src=Path(f['path']) if f['path'].startswith('/') else repo/f['path']
 if sha(src.read_bytes())!=f['sha256']:raise SystemExit('Supporting input changed during capture: '+f['path'])
manifest={'scope':'Exact final frozen AFTER implementation, all direct static module dependencies, registry and measured proof bytes, target tests and authorized unchanged-case runner snapshots. Read-only repository review.','files':files,'supportingInputs':support,'candidateSha256':'e4cf124385a7e199672ab9268987d5ebf08f64d4cc08819e9e721596bce8c5e6','sourceSnapshotPath':str(out),'runnerSha256':'8e2818893e888fa3fe280b3fbe65704c6dfe76c5bf683210675b17bc358134ec'}
p=out/'capture-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'capture':str(out),'manifestSha256':sha(p.read_bytes()),'files':len(files),'supportingInputs':len(support),'expectedHashesVerified':True}))
